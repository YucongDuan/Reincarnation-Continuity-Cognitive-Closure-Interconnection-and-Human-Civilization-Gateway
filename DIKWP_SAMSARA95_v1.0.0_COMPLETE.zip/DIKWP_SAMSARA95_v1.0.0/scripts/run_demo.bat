@echo off
set PYTHONPATH=src
python run.py doctor || exit /b 1
if exist outputs\samsara_demo rmdir /s /q outputs\samsara_demo
python run.py demo --out outputs\samsara_demo || exit /b 1
python run.py verify outputs\samsara_demo || exit /b 1
