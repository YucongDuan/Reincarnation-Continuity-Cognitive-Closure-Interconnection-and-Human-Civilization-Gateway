#!/usr/bin/env sh
set -eu
PYTHONPATH=src python run.py doctor
rm -rf outputs/samsara_demo
PYTHONPATH=src python run.py demo --out outputs/samsara_demo
PYTHONPATH=src python run.py verify outputs/samsara_demo
