from __future__ import annotations
from pathlib import Path
import json, sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from dikwp_samsara95.registries import validate_registries
from dikwp_samsara95.verify import verify_output_dir

registry=validate_registries()
compiled=verify_output_dir(ROOT/'outputs'/'samsara_demo')
result={"registries":registry,"compiled_output":compiled,"valid":registry["valid"] and compiled["valid"]}
print(json.dumps(result,ensure_ascii=False,indent=2))
raise SystemExit(0 if result["valid"] else 1)
