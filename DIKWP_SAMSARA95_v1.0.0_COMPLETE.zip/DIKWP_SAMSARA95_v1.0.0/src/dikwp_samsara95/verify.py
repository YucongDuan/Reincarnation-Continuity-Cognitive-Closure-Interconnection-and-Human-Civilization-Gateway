from __future__ import annotations

from pathlib import Path
from typing import Any

from .registries import validate_registries
from .utils import deep_without, load_json, sha256_bytes, sha256_obj


REQUIRED_FILES = [
    "samsara_bundle.json",
    "ultimate_reincarnation_explanation.json",
    "continuity_model_registry.json",
    "tradition_continuity_mappings.json",
    "human_civilization_gateway.json",
    "human_civilization_gateway.jsonld",
    "cognitive_closure_passports.json",
    "public_closure_passports.json",
    "interclosure_bridge_matrix.json",
    "demo_interclosure_bridge.json",
    "handshake_protocol.json",
    "claim_audit.json",
    "continuity_assessments.json",
    "a2a_agent_card.json",
    "a2a_profile_status.json",
    "mcp_tool_manifest.json",
    "openapi.json",
    "REINCARNATION_ULTIMATE_EXPLANATION_CN.md",
    "FULL_SYSTEM_REPORT_CN.md",
    "dashboard.html",
    "MANIFEST.json",
]


def _non_null_certificates(value: Any, path: str = "") -> list[str]:
    """Find prohibited non-null *leaf* certificates without flagging containers or counters."""
    bad: list[str] = []
    if isinstance(value, dict):
        for key, item in value.items():
            next_path = f"{path}.{key}" if path else key
            if isinstance(item, (dict, list)):
                bad.extend(_non_null_certificates(item, next_path))
                continue
            lower = key.casefold()
            is_certificate_leaf = lower.endswith("_certificate") or (path.endswith("certificates") and lower in {
                "ultimate_truth", "reincarnation", "same_first_person", "consciousness",
                "religious_truth", "human_representation"
            })
            if is_certificate_leaf and item is not None:
                bad.append(next_path)
    elif isinstance(value, list):
        for i, item in enumerate(value):
            bad.extend(_non_null_certificates(item, f"{path}[{i}]"))
    return bad


def verify_output_dir(output_dir: str | Path) -> dict[str, Any]:
    root = Path(output_dir)
    errors: list[str] = []
    warnings: list[str] = []
    for name in REQUIRED_FILES:
        if not (root / name).is_file():
            errors.append(f"Missing required file: {name}")
    if errors:
        return {"valid": False, "errors": errors, "warnings": warnings, "automatic_external_action_authority": 0}

    registry_validation = validate_registries()
    if not registry_validation["valid"]:
        errors.extend(f"Registry: {item}" for item in registry_validation["errors"])

    manifest = load_json(root / "MANIFEST.json")
    checked = 0
    for record in manifest.get("files", []):
        path = root / record["path"]
        if not path.is_file():
            errors.append(f"Manifest file missing: {record['path']}")
            continue
        if sha256_bytes(path.read_bytes()) != record["sha256"]:
            errors.append(f"Digest mismatch: {record['path']}")
        if path.stat().st_size != record["bytes"]:
            errors.append(f"Size mismatch: {record['path']}")
        checked += 1
    if manifest.get("file_count") != checked:
        errors.append("Manifest checked file count mismatch")

    bundle = load_json(root / "samsara_bundle.json")
    expected_digest = bundle.get("bundle_digest")
    if sha256_obj(deep_without(bundle, "generated_at", "bundle_digest")) != expected_digest:
        errors.append("Bundle digest mismatch")

    summary = bundle.get("summary", {})
    if summary.get("continuity_dimension_count") != 16:
        errors.append("Continuity dimension count must equal 16")
    if summary.get("continuity_model_count", 0) < 8:
        errors.append("At least eight continuity models required")
    if summary.get("tradition_mapping_count") != 36:
        errors.append("Tradition mapping count must equal 36")
    if summary.get("civilization_lens_count", 0) < 20:
        errors.append("At least 20 human-civilization lenses required")
    if summary.get("binary_reincarnation_certificates_issued") != 0:
        errors.append("Binary reincarnation certificates must remain zero")

    design = bundle.get("design_thesis", {})
    required_design = [
        "reincarnation_is_a_family_of_continuity_topologies",
        "identity_is_model_relative_and_must_be_declared",
        "all_registered_semantics_enter_dikwp_space",
        "normalization_does_not_claim_doctrinal_equivalence",
        "cognitive_passport_is_interface_not_subject",
        "human_civilization_gateway_is_plural_and_non_total",
        "agent_interoperability_does_not_imply_shared_consciousness",
        "successor_freedom_is_mandatory",
    ]
    for key in required_design:
        if design.get(key) is not True:
            errors.append(f"Design invariant missing: {key}")

    mappings = bundle.get("tradition_mappings", {})
    if mappings.get("permanent_outside_semantic_zone") is not False:
        errors.append("Permanent outside semantic zone must be disabled")
    if float(mappings.get("out_of_space_residual", 1.0)) != 0.0:
        errors.append("Out-of-space residual must equal zero")
    for record in mappings.get("records", []):
        if record.get("doctrinal_equivalence_claim") is not False:
            errors.append(f"Doctrinal equivalence improperly enabled for {record.get('tradition_id')}")

    models = bundle.get("continuity_models", {})
    if models.get("single_model_final_authority") is not False:
        errors.append("Single-model final authority must be false")
    if models.get("automatic_metaphysical_truth_authority") != 0:
        errors.append("Metaphysical truth authority must equal zero")

    bad_certificates = _non_null_certificates(bundle)
    if bad_certificates:
        errors.append("Non-null prohibited certificates: " + ", ".join(bad_certificates[:20]))

    authority_keys = [
        "automatic_external_action_authority",
        "automatic_identity_assignment_authority",
        "automatic_metaphysical_truth_authority",
        "automatic_consciousness_status_authority",
        "automatic_religious_representation_authority",
        "automatic_human_representation_authority",
        "automatic_publication_authority",
        "automatic_self_modification_authority",
    ]
    for key in authority_keys:
        if bundle.get(key) != 0:
            errors.append(f"{key} must equal zero")

    passports = bundle.get("cognitive_closure_passports", {})
    if passports.get("synthetic_only") is not True:
        errors.append("Compiled demo passports must be synthetic-only")
    public = bundle.get("public_closure_passports", {}).get("records", [])
    for record in public:
        if "vulnerabilities" in record or "memory" in record:
            errors.append(f"Sensitive field leaked into public passport {record.get('passport_id')}")
        if record.get("disclosure_contract", {}).get("may_not_be_used_to_assign_identity") is not True:
            errors.append("Public passport identity boundary missing")

    n = passports.get("count", 0)
    matrix = bundle.get("interclosure_bridge_matrix", {})
    if matrix.get("bridge_count") != n * (n - 1) // 2:
        errors.append("Bridge matrix does not cover every unordered passport pair")
    for bridge in matrix.get("bridges", []):
        if bridge.get("identity_equivalence_certificate") is not None:
            errors.append("Bridge issued identity equivalence certificate")
        if bridge.get("automatic_connection_authority") != 0:
            errors.append("Bridge automatic connection authority must equal zero")

    handshake = bundle.get("demo_handshake_protocol", {})
    if handshake.get("connection_authorized") is not False:
        errors.append("Handshake must remain proposal-only")
    if handshake.get("external_action_authorized") is not False:
        errors.append("Handshake must not authorize external action")
    if handshake.get("implicit_consent_allowed") is not False:
        errors.append("Handshake must not allow implicit consent")

    gateway = bundle.get("human_civilization_gateway", {})
    if gateway.get("plural_and_non_total") is not True:
        errors.append("Human civilization gateway must be plural and non-total")
    if gateway.get("machine_reading_contract", {}).get("no_hidden_psychographic_targeting") is not True:
        errors.append("Hidden psychographic targeting prohibition missing")
    if gateway.get("machine_reading_contract", {}).get("individual_self_description_has_priority_over_group_inference") is not True:
        errors.append("Individual self-description priority missing")

    jsonld = load_json(root / "human_civilization_gateway.jsonld")
    if "@context" not in jsonld or "@id" not in jsonld:
        errors.append("Invalid minimal JSON-LD gateway")

    card = load_json(root / "a2a_agent_card.json")
    required_card = {"name", "description", "supportedInterfaces", "version", "capabilities", "defaultInputModes", "defaultOutputModes", "skills"}
    if not required_card.issubset(card):
        errors.append("A2A Agent Card missing required v1 profile fields")
    if not card.get("supportedInterfaces") or card["supportedInterfaces"][0].get("protocolVersion") != "1.0":
        errors.append("A2A v1.0 interface declaration missing")
    profile = load_json(root / "a2a_profile_status.json")
    if profile.get("profileOnly") is not True or profile.get("independentConformanceCertification") is not False:
        errors.append("A2A profile limitations missing")

    mcp = load_json(root / "mcp_tool_manifest.json")
    if mcp.get("protocolVersion") != "2026-07-28":
        errors.append("MCP protocol version mismatch")
    if mcp.get("stateless") is not True:
        errors.append("Modern MCP profile must be stateless")
    if mcp.get("security", {}).get("automaticExternalActionAuthority") != 0:
        errors.append("MCP automatic external action authority must equal zero")
    if any(tool.get("annotations", {}).get("readOnlyHint") is not True for tool in mcp.get("tools", [])):
        errors.append("Every MCP tool must be marked read-only")

    dashboard = (root / "dashboard.html").read_text(encoding="utf-8")
    if "<script src=" in dashboard.casefold():
        errors.append("Dashboard contains external script reference")
    if "Automatic external action authority: 0" not in dashboard:
        errors.append("Dashboard authority boundary missing")

    return {
        "valid": not errors,
        "errors": errors,
        "warnings": warnings,
        "checked_manifest_files": checked,
        "manifest_file_count": manifest.get("file_count"),
        "compilation_id": bundle.get("compilation_id"),
        "bundle_digest": expected_digest,
        "continuity_dimension_count": summary.get("continuity_dimension_count"),
        "continuity_model_count": summary.get("continuity_model_count"),
        "tradition_mapping_count": summary.get("tradition_mapping_count"),
        "civilization_lens_count": summary.get("civilization_lens_count"),
        "closure_passport_count": summary.get("closure_passport_count"),
        "bridge_count": summary.get("interclosure_bridge_count"),
        "claim_count": summary.get("claim_count"),
        "binary_reincarnation_certificates_issued": 0,
        "automatic_external_action_authority": 0,
    }
