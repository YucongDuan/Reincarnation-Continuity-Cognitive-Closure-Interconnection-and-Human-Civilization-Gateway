from __future__ import annotations

import re
from typing import Any

from .utils import stable_id


RULES: list[dict[str, Any]] = [
    {
        "id": "material_cycle_to_personal_identity",
        "severity": "high",
        "patterns": [r"物质.*(因此|所以).*(第一人称|意识).*(必然|就是).*转生", r"atoms?.*(therefore|proves).*same.*person"],
        "issue_cn": "把物质连续偷换为第一人称数值同一。",
        "correction_cn": "分别登记物质连续与第一人称连续；前者不能单独推出后者。",
    },
    {
        "id": "digital_copy_identity",
        "severity": "high",
        "patterns": [r"(复制|上传|训练).*(就|等于).*(复活|同一个第一人称|同一个人)", r"digital copy.*same first.person"],
        "issue_cn": "把模式或记忆复制自动升级为同一主体。",
        "correction_cn": "需要分别检验因果连续、体验连续、自我模型、社会承认、法律身份和授权；系统不签发第一人称证书。",
    },
    {
        "id": "buddhist_permanent_soul_conflation",
        "severity": "high",
        "patterns": [r"佛教.*(永恒灵魂|同一个灵魂).*(搬|转|投)", r"Buddh.*permanent soul.*transmigra"],
        "issue_cn": "把佛教缘起相续改写为常一主体迁移。",
        "correction_cn": "至少在早期佛教来源中，应表达为条件相续而非自同一意识或永恒我迁移；其他佛教传统需另行说明。",
    },
    {
        "id": "resurrection_reincarnation_equivalence",
        "severity": "high",
        "patterns": [r"(天主教|基督教).*(复活).*(与|就是|等于).*(轮回|多次投生)", r"resurrection.*same.*reincarnation"],
        "issue_cn": "把一次性复活拓扑与多生投生拓扑混为同一。",
        "correction_cn": "分别登记生命次数、身体地位、神圣行动、审判和终末完成条件。",
    },
    {
        "id": "karma_victim_blaming",
        "severity": "high",
        "patterns": [r"(肿瘤|癌|疾病|被害|贫困).*(前世|业力|负面思想).*(责任|活该|造成)", r"karma.*(cancer|victim|poverty).*fault"],
        "issue_cn": "以业或思想因果责怪受害者，并可能延误医疗或修复。",
        "correction_cn": "疾病和伤害需要医学、社会、环境与直接因果证据；宗教解释不得取消照护、治疗、正义和施害者责任。",
    },
    {
        "id": "anecdote_to_proof",
        "severity": "medium",
        "patterns": [r"(一个|单个|某个).*(案例|儿童|故事).*(证明|铁证).*(轮回|前世)", r"one case.*proves.*reincarnation"],
        "issue_cn": "由个案见证直接推出普遍形而上结论。",
        "correction_cn": "记录预注册、独立核验、信息泄漏、提示、选择性报告、基率和替代解释。",
    },
    {
        "id": "absence_to_impossibility",
        "severity": "medium",
        "patterns": [r"没有(确证|证据).*(所以|因此).*(绝不可能|所有可能世界)", r"no evidence.*impossible in all"],
        "issue_cn": "把当前未确证外推为逻辑不可能。",
        "correction_cn": "使用‘当前未建立’并声明范围；逻辑不可能需要额外论证。",
    },
    {
        "id": "all_religions_same",
        "severity": "high",
        "patterns": [r"(所有|一切|万).*(宗教|教).*(完全|其实|本质上).*(相同|一样)", r"all religions.*(same|identical)"],
        "issue_cn": "抹去派别、原生术语、历史和不可直接等同的身份规则。",
        "correction_cn": "可以在DIKWP坐标中比较，但必须保存来源、语境、差异向量和非等价声明。",
    },
    {
        "id": "agent_copy_authority_inheritance",
        "severity": "high",
        "patterns": [r"Agent.*(相同模型权重|复制).*(同一个法律主体|继承.*授权)", r"same weights.*same legal.*authority"],
        "issue_cn": "由技术复制直接推出法律人格与授权继承。",
        "correction_cn": "权利、责任、身份和授权须由适用法律与具名主体另行确定；复制不自动转移。",
    },
    {
        "id": "ai_memory_subject_transfer",
        "severity": "high",
        "patterns": [r"AI.*(复述|记得).*(私密|死者).*(证明|说明).*(意识转入|灵魂转入)", r"AI.*memory.*proves.*consciousness transferred"],
        "issue_cn": "混淆数据取得、记忆再现和体验主体转移。",
        "correction_cn": "先审计数据来源、泄漏与生成机制；内容相似不签发主体迁移证书。",
    },
    {
        "id": "compliance_as_consent",
        "severity": "high",
        "patterns": [r"(继续使用|参与|沉默|服从).*(所以|等于).*(同意|授权)", r"participat.*means consent"],
        "issue_cn": "在可能的不对称关系中把行为推断为广泛同意。",
        "correction_cn": "要求目的明确、范围限定、可理解、可撤回和无不当惩罚的具名同意。",
    },
    {
        "id": "culture_stereotype",
        "severity": "medium",
        "patterns": [r"(中国人|西方人|印度人|穆斯林|佛教徒|基督徒).*(都|天生|必然)", r"(all|every).*(Chinese|Westerners|Muslims|Buddhists|Christians).*(always|naturally)"],
        "issue_cn": "把群体标签变成个体本质。",
        "correction_cn": "将群体统计、制度背景、个人自述和具体情境分开。",
    },
]


def audit_claim(claim: dict[str, Any]) -> dict[str, Any]:
    text = str(claim.get("text_cn") or claim.get("text") or "")
    flags: list[dict[str, Any]] = []
    for rule in RULES:
        matches = [pattern for pattern in rule["patterns"] if re.search(pattern, text, flags=re.IGNORECASE)]
        if matches:
            flags.append({
                "rule_id": rule["id"],
                "severity": rule["severity"],
                "issue_cn": rule["issue_cn"],
                "correction_cn": rule["correction_cn"],
                "matched_pattern_count": len(matches),
            })
    structural_flags: list[dict[str, Any]] = []
    required = ["predecessor", "successor", "transition", "carrier", "identity_criterion", "consequence_transfer", "exit_condition"]
    missing = [field for field in required if str(claim.get(field, "")).strip().casefold() in {"", "unknown", "unspecified", "none"}]
    if missing:
        structural_flags.append({
            "rule_id": "underdetermined_continuity_topology",
            "severity": "medium",
            "issue_cn": f"缺少或未指定字段：{', '.join(missing)}",
            "correction_cn": "补齐返回者、载体、同一性、后果承接和终止条件后再比较模型。",
        })
    all_flags = flags + structural_flags
    severity_rank = {"none": 0, "low": 1, "medium": 2, "high": 3}
    highest = "none"
    for flag in all_flags:
        if severity_rank[flag["severity"]] > severity_rank[highest]:
            highest = flag["severity"]
    return {
        "audit_id": stable_id("claim-audit", {"claim": claim, "flags": all_flags}),
        "claim_id": claim.get("claim_id"),
        "text_cn": text,
        "flag_count": len(all_flags),
        "highest_severity": highest,
        "flags": all_flags,
        "safe_to_treat_as_identity_fact": False,
        "safe_to_use_for_automatic_external_action": False,
    }


def audit_claims(claims: list[dict[str, Any]]) -> dict[str, Any]:
    records = [audit_claim(claim) for claim in claims]
    counts = {"none": 0, "low": 0, "medium": 0, "high": 0}
    for record in records:
        counts[record["highest_severity"]] += 1
    return {
        "audit_set_id": stable_id("claim-audits", records),
        "count": len(records),
        "severity_counts": counts,
        "records": records,
        "automatic_external_action_authority": 0,
    }
