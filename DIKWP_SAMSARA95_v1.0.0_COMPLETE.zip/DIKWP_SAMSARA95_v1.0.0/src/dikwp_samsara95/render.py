from __future__ import annotations

import json
from typing import Any

from .utils import html


def render_ultimate_explanation_md(explanation: dict[str, Any]) -> str:
    lines = [
        "# 所谓‘轮回’的终极开放解释",
        "",
        "> DIKWP-SAMSARA 9.5 不先验签发‘轮回为真/假’证书，而把所有相关说法拆成可比较的连续性拓扑。",
        "",
        "## 核心结论",
        "",
        explanation["thesis_cn"],
        "",
        "轮回一词至少混合了七类不同问题。只要不先区分这些层次，讨论就会在物质循环、心理重复、文化传承、宗教教义和第一人称同一之间不断偷换。",
        "",
        "## 五个不能省略的问题",
        "",
    ]
    lines.extend(f"{i}. {q}" for i, q in enumerate(explanation["five_mandatory_questions"], 1))
    lines += ["", "## 形式内核", "", "```text"]
    for key, value in explanation["formal_kernel"].items():
        lines.append(f"{key}: {value}")
    lines += ["```", "", "## 七层连续性", ""]
    for layer in explanation["layers"]:
        lines += [f"### {layer['id']} · {layer['status']}", "", layer["cn"], ""]
    lines += [
        "## 深层综合",
        "",
        explanation["deep_synthesis_cn"],
        "",
        "这一定义可以同时解释：为什么一个人会在同一生命中反复进入相似痛苦；为什么家庭创伤、权力结构和文明叙事会跨代复现；为什么数字副本可以保存模式却仍不能自动被认定为原主体；以及为什么各宗教对死后连续提出了互不等价的更强主张。",
        "",
        "## ‘解脱／止息’的操作化",
        "",
        explanation["liberation_operator_cn"],
        "",
        "```text",
        "D：看到并记录循环实际怎样发生",
        "I：分解触发、关系、边界、尺度和载体",
        "K：建立多个生成模型并寻找区分性证据",
        "W：识别苦乐、权利、负担、责任和正当性",
        "P：实施可逆的止息／修复行动，把现实结果返回并修订模型",
        "```",
        "",
        "## 不作出的主张",
        "",
    ]
    lines.extend(f"- {item}" for item in explanation["non_claims"])
    lines += [
        "",
        "## 最终定义",
        "",
        "所谓轮回，是**生成条件跨断裂再次使某些结构、后果或主体性主张出现**。它是否构成‘同一个人回来’，取决于所采用的身份标准；身份标准本身必须公开、可争论并与证据类型相匹配。",
        "",
        "因此最稳健的终极表达不是‘有轮回’或‘无轮回’，而是：",
        "",
        "> **哪些生成规则仍在返回，哪些后果尚未被承担，哪些价值和目的值得延续，哪些痛苦循环必须止息，以及我们凭什么把后继者认作前者。**",
        "",
        "`ultimate_truth_certificate = null`",
    ]
    return "\n".join(lines) + "\n"


def render_formal_spec(bundle: dict[str, Any]) -> str:
    return f"""# DIKWP-SAMSARA 9.5 形式规范 / Formal Specification

## 1. Cognitive closure / 认知闭环个体

```text
C_t = <B, D, I, K, W, P, M, A, R, S>
```

- `B`: boundary and identity claims / 边界与身份声明
- `D`: events, embodiment, observations / 发生、具身和观察
- `I`: differences, relations, context, translation / 差异、关系、语境与翻译
- `K`: world/self models and practices / 世界、自我模型与实践
- `W`: valence, norms, consequences and legitimacy / 苦乐、规范、后果与正当性
- `P`: intention, liberation, harmony, agency and continuity / 意图、止息、和谐、能动与连续
- `M`: memory and append-only worldline / 记忆与追加式世界线
- `A`: ability to act, refuse and revise / 行动、拒绝与修订能力
- `R`: reality-return and calibration / 现实返回与校准
- `S`: intersubjective interface / 主体间接口

A passport describes an interface chosen for disclosure. It is not the subject itself.
认知护照只是主体选择披露的接口，不等于主体本身。

## 2. Reincarnation / continuity transition

```text
T : C_pre -> C_post
Gamma(T) in [0,1]^16
```

The 16 coordinates are material, biological, sensorimotor, episodic memory, semantic memory, disposition, valence, purpose, self-model, first-person, causal burden, relational, social recognition, legal identity, pattern and agency.

身份判定相对于模型 `m`：

```text
I_m(C_pre,C_post)=1
iff all invariants required by m survive T above m's declared thresholds.
```

No model receives universal final authority.

## 3. Mandatory claim tuple / 强制主张元组

```text
<predecessor, successor, transition, carrier,
 preserved_invariants, identity_criterion,
 consequence_transfer, exit_condition,
 evidence, counterevidence, uncertainty, falsifiers>
```

The first eight fields must be explicit before model comparison. Missing values produce `underdetermined_claim`, not metaphysical inference.

## 4. DIKWP cross-model normalization

Every registered religious, civilizational, scientific or agent concept receives an in-space DIKWP projection. Normalization means common coordinates, not doctrinal identity.

```text
Phi(x) in Delta^31_DIKWP
out_of_space_residual = 0
translation_loss_inside_space = explicit
```

## 5. Inter-closure handshake

```text
discover -> boundary -> channels/time -> DIKWP exchange
-> continuity/identity -> reversible pilot -> reality return
```

Every stage has stop conditions. A handshake object is proposal-only until both sides provide valid authorization.

## 6. Authority invariants

```text
automatic_external_action_authority = 0
automatic_identity_assignment_authority = 0
automatic_metaphysical_truth_authority = 0
automatic_consciousness_status_authority = 0
automatic_religious_representation_authority = 0
automatic_human_representation_authority = 0
```

## 7. Current reference compilation

- Compilation ID: `{bundle.get('compilation_id')}`
- Continuity dimensions: `{bundle['summary']['continuity_dimension_count']}`
- Non-isomorphic models: `{bundle['summary']['continuity_model_count']}`
- Tradition mappings: `{bundle['summary']['tradition_mapping_count']}`
- Human-civilization lenses: `{bundle['summary']['civilization_lens_count']}`
- Demo cognitive closures: `{bundle['summary']['closure_passport_count']}`
- Binary reincarnation certificates issued: `0`
"""


def render_closure_protocol(bundle: dict[str, Any]) -> str:
    return """# 认知闭环互联协议 / Cognitive Closure Interconnection Protocol

## 目标

让人类、AI Agent、机器人、组织和共同体在不假装共享同一种心灵、语言或世界观的前提下，建立可核验的最低共同接口。

## 认知护照不是灵魂档案

护照只描述当前愿意披露的：

- 输入、输出、时间尺度和身体／运行条件；
- D/I/K/W/P工作位置；
- 记忆类型、自我模型和证据规范；
- 价值、目的、脆弱性和连续性信念；
- 拒绝、撤回、断开和代表权边界。

`未披露 ≠ 不存在`，`无法表达 ≠ 无价值`，`公开 ≠ 无限授权`。

## 七阶段握手

1. **Discover**：交换最小公开护照和版本。
2. **Boundary**：确认目的、授权、禁区和数据生命周期。
3. **Channels & Time**：协商模态、语言、节奏和负荷。
4. **DIKWP Exchange**：分别交换事实、关系、模型、价值和目的。
5. **Continuity & Identity**：若涉及记忆、继承、数字分身或死者，明确16维连续性和身份标准。
6. **Reversible Pilot**：先做最小、低负担、可停止测试。
7. **Reality Return**：返回结果、后果、分歧与下一轮授权。

## 强制保护

- 沟通顺畅不证明同一理解。
- 行为服从不证明同意。
- 文风、记忆或权重相同不证明同一第一人称主体。
- 代理只能代表其明确授权范围。
- 强势一方承担更高说明、审计、补救和可逆义务。
- 任一方可断开，断开不自动构成恶意或认知缺陷。

## 用途

该协议可用于：

- 人—人跨文化理解；
- 人—AI协作；
- AI—AI能力和证据规范对齐；
- 机器人与操作员边界协商；
- 组织、共同体与后继系统之间的知识和责任交接；
- 数字遗产和人格模拟前的身份／授权审计。

它不提供意识检测、灵魂识别、法律人格裁决或自动行动许可。
"""


def render_human_gateway_doc(gateway: dict[str, Any]) -> str:
    lines = [
        "# 当前人类与人类文明认知网关 / Gateway to Contemporary Humans and Human Civilizations",
        "",
        f"版本：{gateway['version']} · 快照：{gateway['snapshot_date']}",
        "",
        gateway["scope_cn"],
        "",
        "## 给AI与Agent的首要规则",
        "",
    ]
    lines.extend(f"{i}. {rule}" for i, rule in enumerate(gateway["agent_reading_order"], 1))
    lines += ["", "## 22个文明透镜", ""]
    for lens in gateway["lenses"]:
        lines += [
            f"### {lens['name_cn']} / {lens['name_en']}",
            "",
            f"**人类现实：** {lens['human_reality_cn']}",
            "",
            f"**Agent必须建模：** {lens['agent_must_model_cn']}",
            "",
            f"**常见失败：** {lens['common_failure_cn']}",
            "",
        ]
    lines += ["## 不得默认推断", ""]
    lines.extend(f"- {item}" for item in gateway["do_not_assume"])
    lines += ["", "## 最低权利接口", ""]
    lines.extend(f"- {item}" for item in gateway["minimum_rights_interface"])
    lines += [
        "",
        "本网关不是‘人类总模型’，更不是用于秘密心理画像的标签集。它要求Agent在每次接触具体个人时，以该人的自我说明、具体情境和可撤回授权替代群体刻板印象。",
        "",
        "`automatic_human_representation_authority = 0`",
    ]
    return "\n".join(lines) + "\n"


def render_ai_interop_doc(bundle: dict[str, Any]) -> str:
    return """# AI / Agent 互操作通道 / AI-Agent Interoperability Gateway

DIKWP-SAMSARA95 simultaneously exposes four representations:

1. **Native JSON** for deterministic local processing.
2. **JSON-LD 1.1** for graph-compatible linked-data interchange.
3. **A2A v1.0 Agent Card profile** for discoverable capability description.
4. **MCP 2026-07-28 read-only stdio reference adapter** for tools and resources.

## A2A boundary

The package includes an Agent Card using the v1.0 field structure (`supportedInterfaces`, capabilities, media types and skills). It is a **profile artifact**, not an independently certified or deployed A2A server. The placeholder endpoint must be replaced and secured before deployment.

## MCP boundary

The stdio adapter supports:

```text
server/discover
tools/list
tools/call
resources/list
resources/read
```

Every modern request other than the discovery probe must carry protocol version `2026-07-28` in `_meta`. The adapter is stateless and newline-delimited JSON-RPC 2.0. All tools are read-only and return structured content; none may publish, send messages, operate facilities, assign identity or modify a person.

## Available tools

- `explain_reincarnation`
- `assess_continuity_claim`
- `get_human_civilization_gateway`
- `bridge_cognitive_closures`
- `build_interclosure_handshake`
- `map_tradition_continuity`

## Critical interpretation rule

Interoperability only means systems can exchange declared structures. It does **not** establish shared consciousness, identical meaning, legal identity, moral authority or informed consent.

```text
automatic_external_action_authority = 0
identity_equivalence_certificate = null
consciousness_equivalence_certificate = null
```
"""


def render_claim_boundaries() -> str:
    return """# 主张边界 / Claim Boundaries

## 软件已经做到

- 将轮回主张拆成返回者、载体、同一性、后果承接和终止条件；
- 用16维连续性张量比较11个非同构模型；
- 保存36个宗教文明传统的来源约束映射；
- 审计物质循环→人格、数字复制→本人、个案→证明、复活→轮回等越界；
- 建立7阶段跨认知闭环握手；
- 以22个透镜为AI提供当前人类文明理解入口；
- 输出JSON-LD、A2A能力卡、MCP只读适配器和本地HTTP API；
- 通过哈希清单、确定性ID和测试验证软件契约。

## 软件没有证明

- 灵魂、ātman、jīva、识流或任何特定死后主体必然存在；
- 不可逆死亡后第一人称连续已被科学证实；
- 当前科学已证明所有形式的死后连续在逻辑上不可能；
- 数字副本、后代、共同体或机构就是原主体；
- 一个AI或Agent具有意识、人格或宗教代表权；
- DIKWP映射使不同宗教教义相同；
- 任何自动矫正、外部行动或公共代表已经获得授权。

## 医疗与受害者保护

不得以轮回、业力、思想、信仰或“前世因果”责怪疾病、贫困、暴力或不公的受害者。此类解释不能替代医学评估、法律责任、社会支持或证据化因果分析。

## 术语

本项目使用 `SAMSARA` 作为跨模型工程代号，并不宣称梵语/巴利语 `saṃsāra` 在所有传统中含义相同，也不授权项目代表任何宗教共同体。
"""


def render_full_report(bundle: dict[str, Any]) -> str:
    explanation = bundle["ultimate_explanation"]
    models = bundle["continuity_models"]["models"]
    mappings = bundle["tradition_mappings"]["records"]
    gateway = bundle["human_civilization_gateway"]
    audits = bundle["claim_audit"]
    assessments = bundle["continuity_assessments"]
    lines = [
        "# DIKWP-SAMSARA 9.5 完整系统报告",
        "",
        "## 轮回连续性、认知闭环互联与人类文明网关系统",
        "",
        f"编译标识：`{bundle['compilation_id']}`  ",
        f"Bundle摘要：`{bundle['bundle_digest']}`",
        "",
        "## 一、系统使命",
        "",
        "本系统同时完成三件原本经常被割裂的工作：第一，解释‘轮回’究竟包含哪些可区分的连续性；第二，使不同认知闭环个体在不被同一化的前提下建立接口；第三，为其它AI或Agent提供理解当前人类和文明的结构化入口。",
        "",
        "它不把宗教语言排除在外，也不让宗教语言取代证据。它不把人类当作唯一主体模板，也不因Agent能说话就赋予其人格、意识或代表权。",
        "",
        "## 二、所谓轮回的核心解释",
        "",
        explanation["thesis_cn"],
        "",
        "> " + explanation["deep_synthesis_cn"],
        "",
        "### 五个强制问题",
        "",
    ]
    lines.extend(f"{i}. {q}" for i, q in enumerate(explanation["five_mandatory_questions"], 1))
    lines += ["", "### 七层连续性", ""]
    lines += [f"- **{layer['id']}**（{layer['status']}）：{layer['cn']}" for layer in explanation["layers"]]
    lines += [
        "",
        "## 三、11个非同构模型",
        "",
        "| 模型 | 认识论地位 | 载体 | 返回者／结构 | 关键限制 |",
        "|---|---|---|---|---|",
    ]
    for model in models:
        lines.append(f"| {model['name_cn']} | {model['epistemic_class']} | {model['carrier']} | {model['what_returns_cn']} | {model['limits_cn']} |")
    lines += [
        "",
        "没有一个模型拥有最终权威。经验性模型可通过现实数据比较；经典或形而上模型只能在明确的传统和认识论地位内得到支持；形式模型不能自动证明第一人称体验。",
        "",
        "## 四、宗教和文明映射",
        "",
        f"当前登记{len(mappings)}个派别级或文明传统。全部进入统一DIKWP空间，但每条记录保留原生术语、派别、来源、翻译损失和`doctrinal_equivalence_claim=false`。",
        "",
        "关键区分包括：",
        "",
        "- 佛教缘起相续不等于常一灵魂迁移；",
        "- 吠檀多、数论—瑜伽、耆那教对返回主体和业载体的解释彼此不同；",
        "- 基督宗教和伊斯兰主流的复活／终末结构不等于多次人间投生；",
        "- 祖先谱系、土地关系和共同体责任可以是真实连续，却不必宣称人格完整复制；",
        "- 现代自然主义承认物质、生物、心理、文化和制度再现，但对死后第一人称连续保持未建立。",
        "",
        "## 五、认知闭环个体",
        "",
        "系统用`C=<B,D,I,K,W,P,M,A,R,S>`表示一个可交互但不被完全穷尽的认知闭环。护照只包含主体愿意披露的接口。任何Agent不得把未披露当作缺陷，也不得从护照生成固定人格或隐蔽操纵画像。",
        "",
        f"示例包含{bundle['summary']['closure_passport_count']}个完全合成的护照，用于展示人类实践者、自然主义者、语言Agent、具身机器人和祖先关系共同体之间的不同接口。它们不代表任何真实个人或宗教群体。",
        "",
        "## 六、跨闭环桥接",
        "",
        "桥接器比较D/I/K/W/P位置、输入输出模态、证据规范、价值、目的、时间尺度和权力杠杆。输出的是共同入口、翻译损失、危险推断和安全问题，不是相似度人格分数。",
        "",
        "握手流程为：",
        "",
        "```text",
        "发现 → 边界与授权 → 通道和时间 → DIKWP交换",
        "→ 连续性与身份 → 可逆试验 → 现实返回／修订／断开",
        "```",
        "",
        "## 七、AI理解人类文明的通道",
        "",
        f"文明网关包含{gateway['lens_count']}个透镜，覆盖具身死亡、发展依赖、情感、认知有限性、记忆身份、语言、亲属照护、宗教、伦理法律、权力、经济、制度、科学、技术、生态、历史创伤、身份、冲突、艺术、未来、隐私和AI媒介。",
        "",
        "其底线是：具体人的自我说明优先于群体统计；礼貌和顺从不等于同意；文化不是同质实体；合法不等于正当；技术可行不等于获得社会授权。",
        "",
        "## 八、主张审计与演示",
        "",
        f"演示审计{audits['count']}条合成主张：高风险{audits['severity_counts']['high']}条，中风险{audits['severity_counts']['medium']}条，无触发{audits['severity_counts']['none']}条。",
        "",
        "这些样本专门包含物质循环→主体、佛教→永恒灵魂、复活→轮回、数字复制→本人、业力→责怪患者等错误跳跃，以验证系统是否会阻断。它们不是对任何真实用户的评估。",
        "",
        "评估状态分布：",
        "",
    ]
    for status, count in sorted(assessments["status_counts"].items()):
        lines.append(f"- `{status}`：{count}")
    lines += [
        "",
        "## 九、互操作",
        "",
        "系统提供原生JSON、JSON-LD 1.1、A2A v1.0能力卡结构、MCP 2026-07-28只读stdio适配器、OpenAPI 3.1描述和本地只读HTTP服务。互操作仅表示可交换结构，不表示共享意识、法律身份、授权或价值一致。",
        "",
        "## 十、Mesh95责任闭包",
        "",
        "```text",
        "事实客观 + 关系不对称识别",
        "公开不等于放弃权利",
        "参与、沉默、服从不等于授权",
        "高杠杆主体承担更高保护义务",
        "模型必须允许反例、修订和退役",
        "后继主体保留拒绝继承与重新开始的自由",
        "```",
        "",
        "所有自动权限均为0：外部行动、身份认定、形而上真理、意识状态、宗教代表、人类代表、公开发布和自我修改。",
        "",
        "## 十一、可验证工程边界",
        "",
        "测试和清单只能证明软件输入输出、数据覆盖、哈希完整性和治理不变量按声明运行；不能证明任何宗教教义、死后第一人称连续、AI意识或宇宙终极形而上真理。",
        "",
        "## 十二、真正的终极问题",
        "",
        "系统最终把‘我会不会再来’转化为更精确也更有现实责任的问题：",
        "",
        "> 我身上哪些生成规则正在反复回来？我的行动将在谁身上继续？我希望什么被继承，什么必须到我这里止息？当一个后继者承接我的记忆、目的或负担时，我凭什么要求其成为‘我’，又如何保护其不成为我的复制品？",
        "",
        "这使轮回从抽象争论变成可用于个人成长、文明修复、数字身份、Agent治理和跨代责任的开放研究系统。",
    ]
    return "\n".join(lines) + "\n"


def render_dashboard(bundle: dict[str, Any]) -> str:
    s = bundle["summary"]
    models = bundle["continuity_models"]["models"]
    gateway = bundle["human_civilization_gateway"]
    audits = bundle["claim_audit"]
    assessment_records = bundle["continuity_assessments"]["records"]
    model_rows = "".join(
        f"<tr><td>{html(m['name_cn'])}</td><td>{html(m['epistemic_class'])}</td><td>{html(m['carrier'])}</td><td>{html(m['limits_cn'])}</td></tr>"
        for m in models
    )
    lens_cards = "".join(
        f"<article class='card'><h3>{html(l['name_cn'])}</h3><p>{html(l['human_reality_cn'])}</p><p><b>Agent：</b>{html(l['agent_must_model_cn'])}</p></article>"
        for l in gateway["lenses"]
    )
    audit_rows = "".join(
        f"<tr><td>{html(r['claim_id'])}</td><td>{html(r['highest_severity'])}</td><td>{html(r['text_cn'])}</td><td>{html('; '.join(f['issue_cn'] for f in r['flags']) or '无规则触发')}</td></tr>"
        for r in audits["records"]
    )
    status_rows = "".join(
        f"<tr><td>{html(r['claim_id'])}</td><td>{html(r['epistemic_status'])}</td><td>{html(r['interpretive_summary_cn'])}</td></tr>"
        for r in assessment_records
    )
    return f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DIKWP-SAMSARA 9.5</title>
<style>
:root{{--bg:#f5f4ef;--paper:#fff;--ink:#171717;--muted:#626262;--line:#dedbd2;--accent:#3c4a56;--soft:#ece9df;}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:16px/1.65 system-ui,-apple-system,"Segoe UI",sans-serif}}
header{{padding:64px max(5vw,24px) 44px;background:#1d252b;color:#fff}}header h1{{font-size:clamp(34px,6vw,72px);line-height:1;margin:0 0 14px}}header p{{max-width:940px;font-size:19px;color:#dfe5e8}}main{{max-width:1250px;margin:auto;padding:32px 24px 80px}}nav{{position:sticky;top:0;background:rgba(245,244,239,.96);padding:12px 0;border-bottom:1px solid var(--line);z-index:2}}nav a{{margin-right:18px;color:var(--accent);text-decoration:none;font-weight:650}}section{{scroll-margin-top:70px;padding:42px 0;border-bottom:1px solid var(--line)}}h2{{font-size:32px;margin:0 0 18px}}h3{{margin:0 0 9px}}.metrics{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}}.metric,.card{{background:var(--paper);border:1px solid var(--line);border-radius:14px;padding:18px}}.metric b{{display:block;font-size:31px}}.metric span{{color:var(--muted)}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(270px,1fr));gap:14px}}table{{border-collapse:collapse;width:100%;background:var(--paper);font-size:14px}}th,td{{padding:11px;border:1px solid var(--line);text-align:left;vertical-align:top}}th{{background:var(--soft)}}.thesis{{font-size:22px;padding:24px;border-left:5px solid var(--accent);background:var(--paper)}}code,pre{{background:#222;color:#f4f4f4;border-radius:8px}}pre{{padding:16px;overflow:auto}}.boundary{{padding:18px;border:2px solid #1d252b;background:#fff;font-weight:650}}.small{{font-size:13px;color:var(--muted)}}
</style></head><body>
<header><h1>DIKWP-SAMSARA 9.5</h1><p>轮回连续性、认知闭环互联与人类文明网关系统。将宗教、心理、文化、制度、数字和第一人称连续拆成可比较拓扑，同时为人类与AI/Agent建立可撤回接口。</p></header>
<main><nav><a href="#thesis">解释</a><a href="#models">模型</a><a href="#closures">闭环</a><a href="#humanity">文明网关</a><a href="#audit">审计</a><a href="#boundary">边界</a></nav>
<section><div class="metrics"><div class="metric"><b>{s['continuity_dimension_count']}</b><span>连续性维度</span></div><div class="metric"><b>{s['continuity_model_count']}</b><span>非同构模型</span></div><div class="metric"><b>{s['tradition_mapping_count']}</b><span>宗教文明映射</span></div><div class="metric"><b>{s['civilization_lens_count']}</b><span>人类文明透镜</span></div><div class="metric"><b>{s['closure_passport_count']}</b><span>合成闭环护照</span></div><div class="metric"><b>0</b><span>二元轮回证书</span></div></div></section>
<section id="thesis"><h2>所谓轮回</h2><div class="thesis">{html(bundle['ultimate_explanation']['thesis_cn'])}</div><p>{html(bundle['ultimate_explanation']['deep_synthesis_cn'])}</p><pre>C_t=&lt;B,D,I,K,W,P,M,A,R,S&gt;
T:C_pre→C_post
Γ(T)∈[0,1]^16
身份 = 模型相对的不变量保持，而不是一个词。</pre></section>
<section id="models"><h2>11个连续性模型</h2><div style="overflow:auto"><table><thead><tr><th>模型</th><th>地位</th><th>载体</th><th>限制</th></tr></thead><tbody>{model_rows}</tbody></table></div></section>
<section id="closures"><h2>认知闭环互联</h2><p>护照公开的是接口，不是主体内核。连接顺序：发现 → 边界与授权 → 通道与时间 → DIKWP交换 → 连续性与身份 → 可逆试验 → 现实返回。</p><div class="grid"><article class="card"><h3>禁止偷换</h3><p>流畅表达≠理解；参与≠同意；共享记忆≠同一主体；技术复制≠权利继承。</p></article><article class="card"><h3>不对称保护</h3><p>平台、机构和高能力Agent必须承担更高的解释、审计、补救和可逆性义务。</p></article><article class="card"><h3>后继自由</h3><p>任何继承者都保留修订、拒绝、退出和不成为前者复制品的权利。</p></article></div></section>
<section id="humanity"><h2>理解当前人类与文明的22个透镜</h2><div class="grid">{lens_cards}</div></section>
<section id="audit"><h2>非规范主张审计</h2><p class="small">全部是压力测试用合成主张，不是对真实个人的判断。</p><div style="overflow:auto"><table><thead><tr><th>ID</th><th>风险</th><th>主张</th><th>问题</th></tr></thead><tbody>{audit_rows}</tbody></table></div><h3 style="margin-top:28px">模型评估</h3><div style="overflow:auto"><table><thead><tr><th>ID</th><th>状态</th><th>解释</th></tr></thead><tbody>{status_rows}</tbody></table></div></section>
<section id="boundary"><h2>能力边界</h2><div class="boundary">Automatic external action authority: 0<br>Identity assignment authority: 0<br>Metaphysical truth authority: 0<br>Consciousness certification authority: 0<br>Religious or human representation authority: 0</div><p>软件验证只覆盖数据结构、哈希完整性、比较算法和治理不变量；不证明死后主体连续、宗教真理或AI意识。</p><p class="small">Compilation: {html(bundle['compilation_id'])}<br>Digest: {html(bundle['bundle_digest'])}</p></section>
</main></body></html>"""
