from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from typing import Any
from urllib.parse import parse_qs, urlparse

from .bridge import build_bridge, build_handshake
from .claims import audit_claim
from .continuity import assess_claim, ultimate_explanation
from .civilization import build_human_civilization_gateway, query_gateway
from .interop import build_a2a_agent_card
from .registries import load_registries


MAX_BODY_BYTES = 1_000_000


def _json_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False).encode("utf-8")


class SamsaraHandler(BaseHTTPRequestHandler):
    server_version = "DIKWP-SAMSARA95/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        return

    def _send(self, status: int, value: Any) -> None:
        body = _json_bytes(value)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-SAMSARA95-External-Action-Authority", "0")
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0 or length > MAX_BODY_BYTES:
            raise ValueError("Request body must be between 1 and 1,000,000 bytes")
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        path = parsed.path
        try:
            if path == "/health":
                self._send(200, {"ok": True, "system": "DIKWP-SAMSARA95", "version": "1.0.0", "automaticExternalActionAuthority": 0})
            elif path == "/v1/reincarnation/explanation":
                self._send(200, ultimate_explanation())
            elif path == "/v1/civilization/pack":
                query = parse_qs(parsed.query).get("q", [""])[0]
                self._send(200, query_gateway(query) if query else build_human_civilization_gateway())
            elif path == "/v1/traditions":
                self._send(200, load_registries()["tradition_mappings"])
            elif path == "/v1/system":
                r = load_registries()
                self._send(200, {
                    "system": "DIKWP-SAMSARA95",
                    "version": "1.0.0",
                    "continuityModels": len(r["continuity_models"]["models"]),
                    "traditionMappings": len(r["tradition_mappings"]["records"]),
                    "civilizationLenses": len(r["civilization_gateway"]["lenses"]),
                    "automaticExternalActionAuthority": 0,
                })
            elif path == "/.well-known/agent-card.json":
                host = self.headers.get("Host", "127.0.0.1:8765")
                self._send(200, build_a2a_agent_card(f"http://{host}/a2a"))
            else:
                self._send(404, {"error": "not found"})
        except Exception as exc:
            self._send(500, {"error": str(exc), "automaticExternalActionAuthority": 0})

    def do_POST(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        try:
            data = self._read_json()
            if parsed.path == "/v1/claims/assess":
                claim = data.get("claim", data)
                audit = audit_claim(claim)
                self._send(200, {"audit": audit, "assessment": assess_claim(claim, audit)})
            elif parsed.path == "/v1/closures/bridge":
                self._send(200, build_bridge(data["passportA"], data["passportB"]))
            elif parsed.path == "/v1/closures/handshake":
                self._send(200, build_handshake(data["passportA"], data["passportB"]))
            else:
                self._send(404, {"error": "not found"})
        except (ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
            self._send(400, {"error": str(exc), "automaticExternalActionAuthority": 0})
        except Exception as exc:
            self._send(500, {"error": str(exc), "automaticExternalActionAuthority": 0})


def serve(host: str = "127.0.0.1", port: int = 8765) -> None:
    if host not in {"127.0.0.1", "localhost", "::1"}:
        raise ValueError("Reference server binds to loopback only")
    httpd = ThreadingHTTPServer((host, int(port)), SamsaraHandler)
    print(json.dumps({"serving": True, "host": host, "port": port, "readOnly": True, "automaticExternalActionAuthority": 0}, ensure_ascii=False))
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
