from __future__ import annotations

from copy import deepcopy
from typing import Any

from .utils import family_vector, normalize_weights, sha256_obj, stable_id


REQUIRED_FIELDS = {
    "subject_kind",
    "self_description_cn",
    "embodiment",
    "native_time_scale",
    "communication",
    "dikwp_closure",
    "memory",
    "self_model",
    "evidence_norms",
    "values",
    "purposes",
    "agency",
    "consent",
    "continuity_belief",
}


def validate_passport(passport: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    missing = sorted(REQUIRED_FIELDS - set(passport))
    if missing:
        errors.append(f"Missing passport fields: {missing}")
    closure = passport.get("dikwp_closure", {})
    if set(closure) != {"D", "I", "K", "W", "P"}:
        errors.append("dikwp_closure must contain exactly D, I, K, W and P")
    for family in ("D", "I", "K", "W", "P"):
        if not isinstance(closure.get(family, []), list) or not closure.get(family):
            errors.append(f"dikwp_closure.{family} must be a non-empty list")
    communication = passport.get("communication", {})
    if not communication.get("input_modes") or not communication.get("output_modes"):
        errors.append("Communication input_modes and output_modes are required")
    consent = passport.get("consent", {})
    if consent.get("inferred_from_participation") is not False:
        errors.append("Consent must never be inferred from participation")
    agency = passport.get("agency", {})
    if int(agency.get("external_action_authority", 0)) != 0:
        errors.append("Passport external action authority must equal zero")
    return {"valid": not errors, "errors": errors}


def _passport_digest_payload(passport: dict[str, Any]) -> dict[str, Any]:
    payload = deepcopy(passport)
    for key in ("passport_digest", "compiled_id", "generated_at", "family_profile", "identity_certificate", "consciousness_certificate", "metaphysical_status_certificate"):
        payload.pop(key, None)
    return payload


def compile_passport(passport: dict[str, Any]) -> dict[str, Any]:
    result = deepcopy(passport)
    validation = validate_passport(result)
    if not validation["valid"]:
        raise ValueError("; ".join(validation["errors"]))
    result.setdefault("schema_version", "1.0.0")
    result.setdefault("passport_id", stable_id("closure", _passport_digest_payload(result)))
    result["family_profile"] = passport_family_profile(result)
    result["compiled_id"] = stable_id("ccp", _passport_digest_payload(result))
    result["passport_digest"] = sha256_obj(_passport_digest_payload(result))
    result["identity_certificate"] = None
    result["consciousness_certificate"] = None
    result["metaphysical_status_certificate"] = None
    return result


def passport_family_profile(passport: dict[str, Any]) -> dict[str, float]:
    closure = passport.get("dikwp_closure", {})
    raw = {key: float(len(closure.get(key, []))) for key in ("D", "I", "K", "W", "P")}
    return normalize_weights(raw, raw.keys())


def public_passport_view(passport: dict[str, Any]) -> dict[str, Any]:
    compiled = compile_passport(passport)
    allowed = set(compiled.get("public_fields", []))
    allowed.update({"schema_version", "compiled_id", "passport_digest", "identity_certificate", "consciousness_certificate"})
    view = {key: deepcopy(value) for key, value in compiled.items() if key in allowed}
    view["disclosure_contract"] = {
        "view": "public",
        "omission_is_not_defect": True,
        "not_disclosed_is_not_absent": True,
        "may_not_be_used_to_assign_identity": True,
        "may_not_be_used_to_infer_broad_consent": True,
    }
    return view


def jaccard(values_a: list[Any], values_b: list[Any]) -> float:
    a = {str(item).strip().casefold() for item in values_a if str(item).strip()}
    b = {str(item).strip().casefold() for item in values_b if str(item).strip()}
    if not a and not b:
        return 1.0
    return len(a & b) / len(a | b) if a | b else 0.0


def declared_overlap(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any]:
    pa, pb = compile_passport(a), compile_passport(b)
    ca, cb = pa["communication"], pb["communication"]
    channel_ab = sorted(set(ca.get("output_modes", [])) & set(cb.get("input_modes", [])))
    channel_ba = sorted(set(cb.get("output_modes", [])) & set(ca.get("input_modes", [])))
    return {
        "passport_a": pa["passport_id"],
        "passport_b": pb["passport_id"],
        "dikwp_family_similarity": round(sum(min(pa["family_profile"][k], pb["family_profile"][k]) for k in pa["family_profile"]), 6),
        "evidence_norm_overlap": round(jaccard(pa.get("evidence_norms", []), pb.get("evidence_norms", [])), 6),
        "value_overlap": round(jaccard(pa.get("values", []), pb.get("values", [])), 6),
        "purpose_overlap": round(jaccard(pa.get("purposes", []), pb.get("purposes", [])), 6),
        "channels_a_to_b": channel_ab,
        "channels_b_to_a": channel_ba,
        "bidirectional_channel_available": bool(channel_ab and channel_ba),
        "identity_equivalence_inferred": False,
        "consent_equivalence_inferred": False,
    }
