from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any

from .bridge import build_bridge, build_handshake
from .claims import audit_claim
from .compiler import MESH_MODE, SYSTEM_NAME, VERSION, compile_system
from .continuity import assess_claim, ultimate_explanation
from .civilization import build_human_civilization_gateway, query_gateway
from .interop import MCP_PROTOCOL_VERSION, build_a2a_agent_card, build_mcp_manifest
from .mcp_stdio import run_stdio
from .registries import load_registries, validate_registries
from .server import serve
from .utils import load_json
from .verify import verify_output_dir


def _print(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False))


def cmd_doctor(_: argparse.Namespace) -> int:
    validation = validate_registries()
    r = load_registries()
    result = {
        "valid": validation["valid"],
        "system": SYSTEM_NAME,
        "version": VERSION,
        "mesh_mode": MESH_MODE,
        "python": sys.version.split()[0],
        "registry_counts": validation["counts"],
        "mcp_protocol_version": MCP_PROTOCOL_VERSION,
        "a2a_profile_version": "1.0",
        "binary_reincarnation_certificates_issued": 0,
        "automatic_external_action_authority": 0,
        "errors": validation["errors"],
    }
    _print(result)
    return 0 if result["valid"] else 1


def cmd_compile(args: argparse.Namespace) -> int:
    bundle = compile_system(args.out, claims_path=args.claims, closures_path=args.closures)
    _print({
        "compiled": True,
        "out": str(Path(args.out).resolve()),
        "compilation_id": bundle["compilation_id"],
        "bundle_digest": bundle["bundle_digest"],
        "summary": bundle["summary"],
        "automatic_external_action_authority": 0,
    })
    return 0


def cmd_explain(_: argparse.Namespace) -> int:
    _print(ultimate_explanation())
    return 0


def _claim_from_args(args: argparse.Namespace) -> dict[str, Any]:
    if args.file:
        data = load_json(args.file)
        if isinstance(data, dict) and "claim" in data:
            return data["claim"]
        if isinstance(data, dict):
            return data
        raise ValueError("Claim file must contain a JSON object")
    text = str(args.text or "").strip()
    if not text:
        raise ValueError("Provide --file or --text")
    return {
        "claim_id": "cli-free-text",
        "text_cn": text,
        "asserted_model": "unspecified",
        "predecessor": "unspecified",
        "successor": "unspecified",
        "transition": "unspecified",
        "carrier": "unspecified",
        "preserved_invariants": [],
        "identity_criterion": "unspecified",
        "consequence_transfer": "unspecified",
        "exit_condition": "unspecified",
        "continuity_vector": {},
        "evidence": [],
        "falsifiers": [],
    }


def cmd_assess(args: argparse.Namespace) -> int:
    claim = _claim_from_args(args)
    audit = audit_claim(claim)
    _print({"audit": audit, "assessment": assess_claim(claim, audit)})
    return 0


def cmd_bridge(args: argparse.Namespace) -> int:
    _print(build_bridge(load_json(args.a), load_json(args.b)))
    return 0


def cmd_handshake(args: argparse.Namespace) -> int:
    _print(build_handshake(load_json(args.a), load_json(args.b)))
    return 0


def cmd_civilization(args: argparse.Namespace) -> int:
    if args.query:
        _print(query_gateway(args.query, args.limit))
    else:
        _print(build_human_civilization_gateway())
    return 0


def cmd_tradition(args: argparse.Namespace) -> int:
    records = load_registries()["tradition_mappings"]["records"]
    matches = [item for item in records if item["tradition_id"] == args.tradition_id]
    if not matches:
        raise ValueError(f"Unknown tradition_id: {args.tradition_id}")
    _print(matches[0])
    return 0


def cmd_profiles(_: argparse.Namespace) -> int:
    _print({"a2a": build_a2a_agent_card(), "mcp": build_mcp_manifest()})
    return 0


def cmd_verify(args: argparse.Namespace) -> int:
    result = verify_output_dir(args.output)
    _print(result)
    return 0 if result["valid"] else 1


def cmd_serve(args: argparse.Namespace) -> int:
    serve(args.host, args.port)
    return 0


def cmd_mcp(_: argparse.Namespace) -> int:
    run_stdio()
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="samsara95", description=SYSTEM_NAME)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("doctor", help="Validate registries and governance invariants")
    p.set_defaults(func=cmd_doctor)

    p = sub.add_parser("demo", help="Compile the bundled synthetic demonstration")
    p.add_argument("--out", default="outputs/samsara_demo")
    p.set_defaults(func=cmd_compile, claims=None, closures=None)

    p = sub.add_parser("compile", help="Compile custom claim and cognitive-closure inputs")
    p.add_argument("--claims", help="JSON list or object containing claims")
    p.add_argument("--closures", help="JSON list or object containing passports")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_compile)

    p = sub.add_parser("explain", help="Return the layered explanation of reincarnation")
    p.set_defaults(func=cmd_explain)

    p = sub.add_parser("assess", help="Audit and compare a continuity claim")
    group = p.add_mutually_exclusive_group(required=True)
    group.add_argument("--file", help="JSON claim object")
    group.add_argument("--text", help="Free text; returned as underdetermined until fields are supplied")
    p.set_defaults(func=cmd_assess)

    p = sub.add_parser("bridge", help="Build a non-authorizing bridge between two passports")
    p.add_argument("--a", required=True, help="Passport A JSON")
    p.add_argument("--b", required=True, help="Passport B JSON")
    p.set_defaults(func=cmd_bridge)

    p = sub.add_parser("handshake", help="Build a proposal-only seven-stage handshake")
    p.add_argument("--a", required=True)
    p.add_argument("--b", required=True)
    p.set_defaults(func=cmd_handshake)

    p = sub.add_parser("civilization", help="Read or query the human-civilization gateway")
    p.add_argument("--query")
    p.add_argument("--limit", type=int, default=6)
    p.set_defaults(func=cmd_civilization)

    p = sub.add_parser("tradition", help="Read a source-bound tradition continuity mapping")
    p.add_argument("tradition_id")
    p.set_defaults(func=cmd_tradition)

    p = sub.add_parser("profiles", help="Print A2A and MCP interoperability profiles")
    p.set_defaults(func=cmd_profiles)

    p = sub.add_parser("serve", help="Run the loopback-only read-only HTTP gateway")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8765)
    p.set_defaults(func=cmd_serve)

    p = sub.add_parser("mcp", help="Run the read-only MCP 2026-07-28 stdio adapter")
    p.set_defaults(func=cmd_mcp)

    p = sub.add_parser("verify", help="Verify a compiled output directory")
    p.add_argument("output")
    p.set_defaults(func=cmd_verify)
    return parser


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        code = args.func(args)
    except (ValueError, KeyError, TypeError, OSError, json.JSONDecodeError) as exc:
        _print({"error": str(exc), "automatic_external_action_authority": 0})
        code = 2
    raise SystemExit(code)
