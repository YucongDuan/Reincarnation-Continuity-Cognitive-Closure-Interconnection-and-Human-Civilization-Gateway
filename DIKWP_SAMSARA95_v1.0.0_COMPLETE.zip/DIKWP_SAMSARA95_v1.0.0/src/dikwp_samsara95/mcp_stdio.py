from __future__ import annotations

import json
import sys
from typing import Any

from .bridge import build_bridge, build_handshake
from .claims import audit_claim
from .continuity import assess_claim, ultimate_explanation
from .civilization import build_human_civilization_gateway, query_gateway
from .interop import MCP_PROTOCOL_VERSION, build_mcp_manifest, mcp_tools
from .registries import load_registries


SERVER_INFO = {"name": "dikwp-samsara95", "version": "1.0.0"}


def _result(request_id: Any, payload: dict[str, Any]) -> dict[str, Any]:
    result = dict(payload)
    result.setdefault("_meta", {})["io.modelcontextprotocol/serverInfo"] = SERVER_INFO
    return {"jsonrpc": "2.0", "id": request_id, "result": result}


def _error(request_id: Any, code: int, message: str, data: Any | None = None) -> dict[str, Any]:
    error: dict[str, Any] = {"code": code, "message": message}
    if data is not None:
        error["data"] = data
    return {"jsonrpc": "2.0", "id": request_id, "error": error}


def _text_content(obj: Any) -> list[dict[str, Any]]:
    return [{"type": "text", "text": json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False)}]


def _request_version(request: dict[str, Any]) -> str | None:
    params = request.get("params") or {}
    meta = params.get("_meta") or {}
    return meta.get("io.modelcontextprotocol/protocolVersion")


def _check_version(request: dict[str, Any]) -> dict[str, Any] | None:
    method = request.get("method")
    requested = _request_version(request)
    if method == "server/discover" and requested is None:
        return None
    if requested != MCP_PROTOCOL_VERSION:
        return _error(
            request.get("id"),
            -32022,
            "Unsupported protocol version",
            {"supported": [MCP_PROTOCOL_VERSION], "requested": requested},
        )
    return None


def dispatch(request: dict[str, Any]) -> dict[str, Any] | None:
    if request.get("jsonrpc") != "2.0":
        return _error(request.get("id"), -32600, "Invalid Request")
    if "id" not in request:
        return None
    version_error = _check_version(request)
    if version_error:
        return version_error
    method = request.get("method")
    params = dict(request.get("params") or {})
    params.pop("_meta", None)

    if method == "server/discover":
        return _result(request["id"], {
            "resultType": "serverDiscovery",
            "supportedProtocolVersions": [MCP_PROTOCOL_VERSION],
            "serverInfo": SERVER_INFO,
            "capabilities": {"tools": {}, "resources": {}},
        })
    if method == "tools/list":
        return _result(request["id"], {"resultType": "toolsList", "tools": mcp_tools()})
    if method == "resources/list":
        resources = [
            {"uri": "samsara95://reincarnation/explanation", "name": "reincarnation-explanation", "title": "轮回终极开放解释", "mimeType": "application/json"},
            {"uri": "samsara95://civilization/gateway", "name": "human-civilization-gateway", "title": "当前人类与文明认知网关", "mimeType": "application/json"},
            {"uri": "samsara95://continuity/models", "name": "continuity-models", "title": "连续性模型注册表", "mimeType": "application/json"},
            {"uri": "samsara95://traditions/mappings", "name": "tradition-mappings", "title": "宗教文明连续性映射", "mimeType": "application/json"},
        ]
        return _result(request["id"], {"resultType": "resourcesList", "resources": resources})
    if method == "resources/read":
        uri = params.get("uri")
        registries = load_registries()
        mapping = {
            "samsara95://reincarnation/explanation": ultimate_explanation(),
            "samsara95://civilization/gateway": build_human_civilization_gateway(),
            "samsara95://continuity/models": registries["continuity_models"],
            "samsara95://traditions/mappings": registries["tradition_mappings"],
        }
        if uri not in mapping:
            return _error(request["id"], -32602, "Unknown resource URI")
        text = json.dumps(mapping[uri], ensure_ascii=False, indent=2)
        return _result(request["id"], {"resultType": "resourceContents", "contents": [{"uri": uri, "mimeType": "application/json", "text": text}]})
    if method == "tools/call":
        name = params.get("name")
        arguments = params.get("arguments") or {}
        try:
            value = call_tool(str(name), arguments)
        except (KeyError, TypeError, ValueError) as exc:
            return _result(request["id"], {"resultType": "toolResult", "isError": True, "content": _text_content({"error": str(exc)})})
        return _result(request["id"], {"resultType": "toolResult", "isError": False, "content": _text_content(value), "structuredContent": value})
    return _error(request["id"], -32601, "Method not found")


def call_tool(name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    if name == "explain_reincarnation":
        return ultimate_explanation()
    if name == "assess_continuity_claim":
        claim = arguments["claim"]
        audit = audit_claim(claim)
        return {"audit": audit, "assessment": assess_claim(claim, audit)}
    if name == "get_human_civilization_gateway":
        query = str(arguments.get("query", "")).strip()
        if query:
            return query_gateway(query, int(arguments.get("limit", 6)))
        return build_human_civilization_gateway()
    if name == "bridge_cognitive_closures":
        return build_bridge(arguments["passportA"], arguments["passportB"])
    if name == "build_interclosure_handshake":
        return build_handshake(arguments["passportA"], arguments["passportB"])
    if name == "map_tradition_continuity":
        tid = str(arguments["traditionId"])
        for item in load_registries()["tradition_mappings"]["records"]:
            if item["tradition_id"] == tid:
                return item
        raise ValueError(f"Unknown traditionId: {tid}")
    raise ValueError(f"Unknown tool: {name}")


def run_stdio() -> None:
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
            response = dispatch(request)
        except json.JSONDecodeError:
            response = _error(None, -32700, "Parse error")
        except Exception as exc:  # defensive protocol boundary
            response = _error(None, -32603, "Internal error", {"detail": str(exc)})
        if response is not None:
            sys.stdout.write(json.dumps(response, ensure_ascii=False, separators=(",", ":")) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    run_stdio()
