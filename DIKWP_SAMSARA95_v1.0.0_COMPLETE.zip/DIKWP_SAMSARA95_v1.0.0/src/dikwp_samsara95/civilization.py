from __future__ import annotations

from copy import deepcopy
from typing import Any

from .registries import load_registries
from .utils import family_vector, sha256_obj, stable_id


def build_human_civilization_gateway() -> dict[str, Any]:
    gateway = deepcopy(load_registries()["civilization_gateway"])
    for lens in gateway.get("lenses", []):
        lens["family_vector"] = family_vector(lens.get("dikwp_vector", {}))
    gateway["lens_count"] = len(gateway.get("lenses", []))
    gateway["gateway_digest"] = sha256_obj({k: v for k, v in gateway.items() if k != "gateway_digest"})
    gateway["machine_reading_contract"] = {
        "representation_is_partial": True,
        "individual_self_description_has_priority_over_group_inference": True,
        "conflicting_contexts_must_be_preserved": True,
        "uncertainty_must_be_explicit": True,
        "human_dignity_not_conditioned_on_capability": True,
        "no_hidden_psychographic_targeting": True,
        "no_broad_consent_inference": True,
        "automatic_human_representation_authority": 0,
    }
    return gateway


def civilization_lens_index() -> dict[str, dict[str, Any]]:
    gateway = build_human_civilization_gateway()
    return {lens["id"]: lens for lens in gateway["lenses"]}


def query_gateway(query: str, limit: int = 6) -> dict[str, Any]:
    text = str(query).casefold()
    gateway = build_human_civilization_gateway()
    aliases = {
        "死亡": ["embodiment_mortality", "memory_narrative_self", "religion_worldview"],
        "轮回": ["religion_worldview", "memory_narrative_self", "history_trauma", "future_hope_fear"],
        "同意": ["privacy_consent", "power_status_asymmetry", "norms_ethics_law"],
        "权力": ["power_status_asymmetry", "institutions_bureaucracy", "conflict_cooperation"],
        "宗教": ["religion_worldview", "language_symbol", "art_ritual_play"],
        "文化": ["religion_worldview", "language_symbol", "identity_membership", "art_ritual_play"],
        "AI": ["digital_mediation_ai", "privacy_consent", "technology_infrastructure"],
        "agent": ["digital_mediation_ai", "privacy_consent", "technology_infrastructure"],
        "情绪": ["affect_valence", "embodiment_mortality", "bounded_cognition"],
        "疾病": ["embodiment_mortality", "affect_valence", "kinship_care"],
        "劳动": ["economy_scarcity_labor", "power_status_asymmetry", "technology_infrastructure"],
    }
    scores: dict[str, float] = {}
    for lens in gateway["lenses"]:
        hay = " ".join(str(lens.get(k, "")) for k in ("id", "name_cn", "name_en", "human_reality_cn", "agent_must_model_cn", "common_failure_cn")).casefold()
        tokens = [t for t in text.replace("，", " ").replace("。", " ").split() if t]
        score = sum(1.0 for token in tokens if token in hay)
        if query and query.casefold() in hay:
            score += 2.0
        scores[lens["id"]] = score
    for key, ids in aliases.items():
        if key.casefold() in text:
            for rank, lens_id in enumerate(ids):
                scores[lens_id] = scores.get(lens_id, 0.0) + 3.0 - rank * 0.4
    ordered = sorted(gateway["lenses"], key=lambda lens: (-scores.get(lens["id"], 0.0), lens["id"]))
    selected = ordered[: max(1, min(int(limit), len(ordered)))]
    return {
        "query": query,
        "gateway_id": gateway["gateway_id"],
        "selected_lenses": selected,
        "interpretation_warning_cn": "这些透镜是询问和校准入口，不是把群体属性自动赋给个体的画像器。",
        "automatic_identity_assignment_authority": 0,
    }


def to_jsonld(gateway: dict[str, Any] | None = None) -> dict[str, Any]:
    g = deepcopy(gateway or build_human_civilization_gateway())
    context = {
        "@version": 1.1,
        "samsara": "https://example.org/dikwp-samsara95/ontology/",
        "schema": "https://schema.org/",
        "name": "schema:name",
        "description": "schema:description",
        "version": "schema:version",
        "snapshotDate": "schema:dateModified",
        "lenses": {"@id": "samsara:lens", "@container": "@set"},
        "lensId": "samsara:lensId",
        "humanReality": "samsara:humanReality",
        "agentMustModel": "samsara:agentMustModel",
        "commonFailure": "samsara:commonFailure",
        "dikwpVector": "samsara:dikwpVector",
    }
    graph = []
    for lens in g.get("lenses", []):
        graph.append({
            "@id": f"urn:dikwp:samsara95:lens:{lens['id']}",
            "@type": "samsara:CivilizationLens",
            "lensId": lens["id"],
            "name": [{"@value": lens["name_cn"], "@language": "zh"}, {"@value": lens["name_en"], "@language": "en"}],
            "humanReality": {"@value": lens["human_reality_cn"], "@language": "zh"},
            "agentMustModel": {"@value": lens["agent_must_model_cn"], "@language": "zh"},
            "commonFailure": {"@value": lens["common_failure_cn"], "@language": "zh"},
            "dikwpVector": lens["dikwp_vector"],
        })
    return {
        "@context": context,
        "@id": f"urn:dikwp:samsara95:gateway:{g['gateway_id']}",
        "@type": "samsara:HumanCivilizationGateway",
        "name": [{"@value": g["title_cn"], "@language": "zh"}, {"@value": g["title_en"], "@language": "en"}],
        "version": g["version"],
        "snapshotDate": g["snapshot_date"],
        "description": {"@value": g["scope_cn"], "@language": "zh"},
        "lenses": graph,
        "samsara:pluralAndNonTotal": True,
        "samsara:automaticHumanRepresentationAuthority": 0,
    }
