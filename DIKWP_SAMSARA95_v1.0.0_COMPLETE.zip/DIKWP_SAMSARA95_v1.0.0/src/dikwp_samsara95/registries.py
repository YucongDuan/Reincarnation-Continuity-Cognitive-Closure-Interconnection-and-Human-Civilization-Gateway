from __future__ import annotations

from typing import Any

from .utils import load_bundled_json


REGISTRY_FILES = {
    "ontology": "dikwp_ontology.json",
    "continuity_models": "continuity_models.json",
    "traditions": "tradition_registry.json",
    "tradition_mappings": "tradition_continuity_mappings.json",
    "sources": "source_registry.json",
    "civilization_gateway": "human_civilization_gateway.json",
    "governance": "governance.json",
    "demo_closures": "demo_closures.json",
    "demo_claims": "demo_claims.json",
}


def load_registries() -> dict[str, Any]:
    return {key: load_bundled_json(name) for key, name in REGISTRY_FILES.items()}


def registry_index(items: list[dict[str, Any]], key: str = "id") -> dict[str, dict[str, Any]]:
    return {str(item[key]): item for item in items}


def validate_registries(registries: dict[str, Any] | None = None) -> dict[str, Any]:
    r = registries or load_registries()
    errors: list[str] = []
    warnings: list[str] = []

    anchors = {item["id"] for item in r["ontology"].get("anchors", [])}
    if len(anchors) != 32:
        errors.append(f"Expected 32 DIKWP anchors; found {len(anchors)}")

    dims = {item["id"] for item in r["continuity_models"].get("continuity_dimensions", [])}
    models = r["continuity_models"].get("models", [])
    if len(dims) != 16:
        errors.append(f"Expected 16 continuity dimensions; found {len(dims)}")
    if len(models) < 8:
        errors.append("At least eight non-isomorphic continuity models are required")
    for model in models:
        vector = model.get("continuity_weights", {})
        unknown = sorted(set(vector) - dims)
        if unknown:
            errors.append(f"Model {model.get('id')} has unknown dimensions: {unknown}")
        total = sum(float(v) for v in vector.values())
        if abs(total - 1.0) > 1e-6:
            errors.append(f"Model {model.get('id')} continuity weights sum to {total}")
        if model.get("binary_reincarnation_certificate", "missing") is not None:
            errors.append(f"Model {model.get('id')} must not issue a binary reincarnation certificate")

    traditions = r["traditions"].get("traditions", [])
    concept_count = sum(len(item.get("concepts", [])) for item in traditions)
    if r["traditions"].get("tradition_count") != len(traditions):
        errors.append("Tradition registry count mismatch")
    if concept_count != 144:
        errors.append(f"Expected 144 registered tradition concepts; found {concept_count}")
    mappings = r["tradition_mappings"].get("records", [])
    tradition_ids = {item.get("id") for item in traditions}
    mapping_ids = {item.get("tradition_id") for item in mappings}
    if r["tradition_mappings"].get("record_count") != len(mappings):
        errors.append("Tradition mapping count mismatch")
    if mapping_ids != tradition_ids:
        missing = sorted(tradition_ids - mapping_ids)
        extra = sorted(mapping_ids - tradition_ids)
        errors.append(f"Tradition mapping coverage mismatch; missing={missing}, extra={extra}")
    if r["tradition_mappings"].get("permanent_outside_semantic_zone") is not False:
        errors.append("Permanent outside semantic zone must be false")
    if float(r["tradition_mappings"].get("out_of_space_residual", 1.0)) != 0.0:
        errors.append("Out-of-space semantic residual must equal zero")

    source_ids = {item["id"] for item in r["sources"].get("sources", [])}
    if r["sources"].get("source_count") != len(source_ids):
        errors.append("Source registry count mismatch")
    for mapping in mappings:
        vector = mapping.get("dikwp_vector", {})
        unknown = sorted(set(vector) - anchors)
        if unknown:
            errors.append(f"Tradition {mapping.get('tradition_id')} has unknown DIKWP anchors: {unknown}")
        total = sum(float(v) for v in vector.values())
        if abs(total - 1.0) > 1e-6:
            errors.append(f"Tradition {mapping.get('tradition_id')} vector sums to {total}")
        for ref in mapping.get("source_refs", []):
            if ref not in source_ids:
                errors.append(f"Tradition {mapping.get('tradition_id')} references unknown source {ref}")
        if mapping.get("doctrinal_equivalence_claim") is not False:
            errors.append(f"Tradition {mapping.get('tradition_id')} improperly claims doctrinal equivalence")

    gateway = r["civilization_gateway"]
    if not gateway.get("plural_and_non_total"):
        errors.append("Human civilization gateway must be plural and non-total")
    for lens in gateway.get("lenses", []):
        vector = lens.get("dikwp_vector", {})
        unknown = sorted(set(vector) - anchors)
        if unknown:
            errors.append(f"Civilization lens {lens.get('id')} has unknown DIKWP anchors: {unknown}")
        total = sum(float(v) for v in vector.values())
        if abs(total - 1.0) > 1e-6:
            errors.append(f"Civilization lens {lens.get('id')} vector sums to {total}")

    authorities = r["governance"].get("authorities", {})
    for key, value in authorities.items():
        if int(value) != 0:
            errors.append(f"Governance authority {key} must equal zero")

    closures = r["demo_closures"].get("passports", [])
    if not r["demo_closures"].get("synthetic_only"):
        errors.append("Demo closure registry must be marked synthetic-only")
    if r["demo_closures"].get("count") != len(closures):
        errors.append("Demo closure count mismatch")

    claims = r["demo_claims"].get("claims", [])
    if not r["demo_claims"].get("synthetic_only"):
        errors.append("Demo claim registry must be marked synthetic-only")
    if r["demo_claims"].get("count") != len(claims):
        errors.append("Demo claim count mismatch")

    return {
        "valid": not errors,
        "errors": errors,
        "warnings": warnings,
        "counts": {
            "dikwp_anchors": len(anchors),
            "continuity_dimensions": len(dims),
            "continuity_models": len(models),
            "traditions": len(traditions),
            "tradition_concepts": concept_count,
            "tradition_mappings": len(mappings),
            "sources": len(source_ids),
            "civilization_lenses": len(gateway.get("lenses", [])),
            "demo_closures": len(closures),
            "demo_claims": len(claims),
        },
    }
