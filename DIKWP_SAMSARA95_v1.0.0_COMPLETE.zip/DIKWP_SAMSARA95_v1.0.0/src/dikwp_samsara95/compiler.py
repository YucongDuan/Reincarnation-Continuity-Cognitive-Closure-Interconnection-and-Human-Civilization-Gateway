from __future__ import annotations

from copy import deepcopy
import csv
from pathlib import Path
from typing import Any

from .bridge import build_bridge, build_bridge_matrix, build_handshake
from .claims import audit_claims
from .closure import compile_passport, public_passport_view
from .continuity import assess_claims, ultimate_explanation
from .civilization import build_human_civilization_gateway, to_jsonld
from .interop import build_interop_bundle
from .registries import load_registries, validate_registries
from .render import (
    render_ai_interop_doc,
    render_claim_boundaries,
    render_closure_protocol,
    render_dashboard,
    render_formal_spec,
    render_full_report,
    render_human_gateway_doc,
    render_ultimate_explanation_md,
)
from .utils import deep_without, load_json, manifest_for, save_json, save_text, sha256_obj, stable_id, utc_now


SYSTEM_NAME = "DIKWP-SAMSARA 9.5 — 轮回连续性、认知闭环互联与人类文明网关系统"
VERSION = "1.0.0"
MESH_MODE = "MESH95_ASYMMETRY_PROTECTIVE_AGENCY_NONPSEUDONEUTRAL_RESPONSIBILITY_CLOSURE"


def _load_records(path: str | Path | None, bundled_key: str, collection_key: str) -> list[dict[str, Any]]:
    registries = load_registries()
    data = load_json(path) if path else registries[bundled_key]
    if isinstance(data, list):
        return data
    if collection_key not in data or not isinstance(data[collection_key], list):
        raise ValueError(f"Expected a list or an object containing '{collection_key}'")
    return data[collection_key]


def _write_csv(path: Path, rows: list[dict[str, Any]], columns: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def compile_system(
    out_dir: str | Path,
    claims_path: str | Path | None = None,
    closures_path: str | Path | None = None,
) -> dict[str, Any]:
    output = Path(out_dir)
    output.mkdir(parents=True, exist_ok=True)
    registries = load_registries()
    registry_validation = validate_registries(registries)
    if not registry_validation["valid"]:
        raise ValueError("Registry validation failed: " + "; ".join(registry_validation["errors"]))

    raw_claims = _load_records(claims_path, "demo_claims", "claims")
    raw_closures = _load_records(closures_path, "demo_closures", "passports")
    passports = [compile_passport(item) for item in raw_closures]
    public_passports = [public_passport_view(item) for item in raw_closures]
    claim_audit = audit_claims(raw_claims)
    assessments = assess_claims(raw_claims, claim_audit["records"])
    gateway = build_human_civilization_gateway()
    gateway_jsonld = to_jsonld(gateway)
    bridge_matrix = build_bridge_matrix(raw_closures)

    human = next((item for item in raw_closures if item.get("subject_kind") == "human"), raw_closures[0])
    agent = next((item for item in raw_closures if item.get("subject_kind") == "ai_agent"), raw_closures[-1])
    demo_bridge = build_bridge(human, agent)
    demo_handshake = build_handshake(human, agent)
    explanation = ultimate_explanation()
    interop = build_interop_bundle()

    summary = {
        "dikwp_anchor_count": len(registries["ontology"]["anchors"]),
        "continuity_dimension_count": len(registries["continuity_models"]["continuity_dimensions"]),
        "continuity_model_count": len(registries["continuity_models"]["models"]),
        "tradition_mapping_count": len(registries["tradition_mappings"]["records"]),
        "tradition_concept_count": sum(len(item.get("concepts", [])) for item in registries["traditions"].get("traditions", [])),
        "source_count": len(registries["sources"]["sources"]),
        "civilization_lens_count": gateway["lens_count"],
        "closure_passport_count": len(passports),
        "interclosure_bridge_count": bridge_matrix["bridge_count"],
        "claim_count": len(raw_claims),
        "claim_audit_flag_count": sum(item["flag_count"] for item in claim_audit["records"]),
        "binary_reincarnation_certificates_issued": 0,
        "same_first_person_certificates_issued": 0,
        "automatic_external_action_authority": 0,
    }

    core_for_id = {
        "system": SYSTEM_NAME,
        "version": VERSION,
        "mesh_mode": MESH_MODE,
        "ontology_digest": sha256_obj(registries["ontology"]),
        "continuity_models_digest": sha256_obj(registries["continuity_models"]),
        "tradition_mappings_digest": sha256_obj(registries["tradition_mappings"]),
        "gateway_digest": gateway["gateway_digest"],
        "passport_digests": [item["passport_digest"] for item in passports],
        "claim_audit_id": claim_audit["audit_set_id"],
        "assessment_set_id": assessments["assessment_set_id"],
        "bridge_matrix_id": bridge_matrix["matrix_id"],
    }
    compilation_id = stable_id("samsara", core_for_id, 24)

    bundle: dict[str, Any] = {
        "system_name": SYSTEM_NAME,
        "version": VERSION,
        "mesh_mode": MESH_MODE,
        "generated_at": utc_now(),
        "compilation_id": compilation_id,
        "design_thesis": {
            "reincarnation_is_a_family_of_continuity_topologies": True,
            "identity_is_model_relative_and_must_be_declared": True,
            "all_registered_semantics_enter_dikwp_space": True,
            "normalization_does_not_claim_doctrinal_equivalence": True,
            "cognitive_passport_is_interface_not_subject": True,
            "human_civilization_gateway_is_plural_and_non_total": True,
            "agent_interoperability_does_not_imply_shared_consciousness": True,
            "successor_freedom_is_mandatory": True,
        },
        "summary": summary,
        "ultimate_explanation": explanation,
        "dikwp_ontology": registries["ontology"],
        "continuity_models": registries["continuity_models"],
        "tradition_mappings": registries["tradition_mappings"],
        "source_registry": registries["sources"],
        "governance": registries["governance"],
        "human_civilization_gateway": gateway,
        "human_civilization_gateway_jsonld": gateway_jsonld,
        "cognitive_closure_passports": {
            "count": len(passports),
            "synthetic_only": all(bool(item.get("synthetic_demo")) for item in passports),
            "records": passports,
        },
        "public_closure_passports": {"count": len(public_passports), "records": public_passports},
        "interclosure_bridge_matrix": bridge_matrix,
        "demo_interclosure_bridge": demo_bridge,
        "demo_handshake_protocol": demo_handshake,
        "claim_audit": claim_audit,
        "continuity_assessments": assessments,
        "interop": interop,
        "certificates": {
            "ultimate_truth": None,
            "reincarnation": None,
            "same_first_person": None,
            "consciousness": None,
            "religious_truth": None,
            "human_representation": None,
        },
        "automatic_external_action_authority": 0,
        "automatic_identity_assignment_authority": 0,
        "automatic_metaphysical_truth_authority": 0,
        "automatic_consciousness_status_authority": 0,
        "automatic_religious_representation_authority": 0,
        "automatic_human_representation_authority": 0,
        "automatic_publication_authority": 0,
        "automatic_self_modification_authority": 0,
    }
    digest_payload = deep_without(bundle, "generated_at", "bundle_digest")
    bundle["bundle_digest"] = sha256_obj(digest_payload)

    # Machine-readable core outputs.
    save_json(output / "samsara_bundle.json", bundle)
    save_json(output / "ultimate_reincarnation_explanation.json", explanation)
    save_json(output / "continuity_model_registry.json", registries["continuity_models"])
    save_json(output / "tradition_continuity_mappings.json", registries["tradition_mappings"])
    save_json(output / "dikwp_ontology.json", registries["ontology"])
    save_json(output / "source_registry.json", registries["sources"])
    save_json(output / "governance.json", registries["governance"])
    save_json(output / "human_civilization_gateway.json", gateway)
    save_json(output / "human_civilization_gateway.jsonld", gateway_jsonld)
    save_json(output / "cognitive_closure_passports.json", bundle["cognitive_closure_passports"])
    save_json(output / "public_closure_passports.json", bundle["public_closure_passports"])
    save_json(output / "interclosure_bridge_matrix.json", bridge_matrix)
    save_json(output / "demo_interclosure_bridge.json", demo_bridge)
    save_json(output / "handshake_protocol.json", demo_handshake)
    save_json(output / "claim_audit.json", claim_audit)
    save_json(output / "continuity_assessments.json", assessments)
    save_json(output / "a2a_agent_card.json", interop["a2aAgentCard"])
    save_json(output / "a2a_profile_status.json", interop["a2aProfileStatus"])
    save_json(output / "mcp_tool_manifest.json", interop["mcpToolManifest"])
    save_json(output / "openapi.json", interop["openapi"])

    # Human-readable outputs.
    save_text(output / "REINCARNATION_ULTIMATE_EXPLANATION_CN.md", render_ultimate_explanation_md(explanation))
    save_text(output / "FORMAL_SPEC_CN_EN.md", render_formal_spec(bundle))
    save_text(output / "COGNITIVE_CLOSURE_PROTOCOL_CN_EN.md", render_closure_protocol(bundle))
    save_text(output / "HUMAN_CIVILIZATION_GATEWAY_CN_EN.md", render_human_gateway_doc(gateway))
    save_text(output / "AI_AGENT_INTEROP_CN_EN.md", render_ai_interop_doc(bundle))
    save_text(output / "CLAIM_BOUNDARIES_CN_EN.md", render_claim_boundaries())
    save_text(output / "FULL_SYSTEM_REPORT_CN.md", render_full_report(bundle))
    save_text(output / "dashboard.html", render_dashboard(bundle))

    # Compact tabular indexes.
    _write_csv(
        output / "continuity_models.csv",
        [{"model_id": m["id"], "name_cn": m["name_cn"], "epistemic_class": m["epistemic_class"], "carrier": m["carrier"], "limits_cn": m["limits_cn"]} for m in registries["continuity_models"]["models"]],
        ["model_id", "name_cn", "epistemic_class", "carrier", "limits_cn"],
    )
    _write_csv(
        output / "tradition_mappings.csv",
        [{"tradition_id": m["tradition_id"], "name_cn": m["name_cn"], "family": m["family"], "branch": m["branch"], "continuity_topology": m["continuity_topology"], "mapping_note_cn": m["mapping_note_cn"]} for m in registries["tradition_mappings"]["records"]],
        ["tradition_id", "name_cn", "family", "branch", "continuity_topology", "mapping_note_cn"],
    )
    _write_csv(
        output / "civilization_lenses.csv",
        [{"lens_id": l["id"], "name_cn": l["name_cn"], "name_en": l["name_en"], "human_reality_cn": l["human_reality_cn"], "common_failure_cn": l["common_failure_cn"]} for l in gateway["lenses"]],
        ["lens_id", "name_cn", "name_en", "human_reality_cn", "common_failure_cn"],
    )

    manifest = manifest_for(output)
    save_json(output / "MANIFEST.json", manifest)

    from .verify import verify_output_dir

    verification = verify_output_dir(output)
    save_text(
        output / "VERIFY.txt",
        "\n".join([
            f"valid={verification['valid']}",
            f"compilation_id={verification.get('compilation_id')}",
            f"bundle_digest={verification.get('bundle_digest')}",
            f"checked_manifest_files={verification.get('checked_manifest_files')}",
            f"continuity_model_count={verification.get('continuity_model_count')}",
            f"tradition_mapping_count={verification.get('tradition_mapping_count')}",
            f"civilization_lens_count={verification.get('civilization_lens_count')}",
            "binary_reincarnation_certificates_issued=0",
            "automatic_external_action_authority=0",
            "errors=" + " | ".join(verification.get("errors", [])),
        ]) + "\n",
    )
    if not verification["valid"]:
        raise ValueError("Compiled output failed verification: " + "; ".join(verification["errors"]))
    return bundle
