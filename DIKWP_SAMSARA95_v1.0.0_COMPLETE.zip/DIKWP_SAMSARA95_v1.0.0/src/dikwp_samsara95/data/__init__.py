"""Bundled registries for DIKWP-SAMSARA 9.5."""
