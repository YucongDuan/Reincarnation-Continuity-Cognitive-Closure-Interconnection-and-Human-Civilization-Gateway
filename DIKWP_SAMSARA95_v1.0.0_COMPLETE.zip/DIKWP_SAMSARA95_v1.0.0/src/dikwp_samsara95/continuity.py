from __future__ import annotations

from copy import deepcopy
from typing import Any

from .registries import load_registries, registry_index
from .utils import cosine_sparse, normalize_weights, stable_id


MANDATORY_CLAIM_FIELDS = (
    "predecessor",
    "successor",
    "transition",
    "carrier",
    "preserved_invariants",
    "identity_criterion",
    "consequence_transfer",
    "exit_condition",
)

EVIDENCE_STRENGTH = {
    "direct_instrumental": 1.0,
    "experimental": 0.95,
    "technical_hash": 0.90,
    "longitudinal": 0.85,
    "established_background": 0.85,
    "documentary": 0.72,
    "formal": 0.70,
    "demonstration": 0.62,
    "testimony": 0.50,
    "scriptural": 0.48,
    "community_testimony": 0.46,
    "anecdotal": 0.22,
    "unsourced_assertion": 0.08,
    "evidence_gap": 0.10,
    "alternative_explanation": 0.55,
}

EMPIRICAL_MODEL_CLASSES = {
    "empirical-naturalist",
    "empirical-biological",
    "empirical-social",
    "empirical-psychological",
}


def continuity_dimensions() -> list[str]:
    registry = load_registries()["continuity_models"]
    return [item["id"] for item in registry["continuity_dimensions"]]


def normalize_continuity_vector(vector: dict[str, Any]) -> dict[str, float]:
    dims = continuity_dimensions()
    unknown = sorted(set(vector) - set(dims))
    if unknown:
        raise ValueError(f"Unknown continuity dimensions: {unknown}")
    return normalize_weights({key: float(vector.get(key, 0.0)) for key in dims}, dims)


def claim_completeness(claim: dict[str, Any]) -> dict[str, Any]:
    present: list[str] = []
    missing: list[str] = []
    placeholders = {None, "", "unknown", "unspecified", "none"}
    for field in MANDATORY_CLAIM_FIELDS:
        value = claim.get(field)
        if isinstance(value, list):
            ok = bool(value)
        else:
            ok = str(value).strip().casefold() not in placeholders
        (present if ok else missing).append(field)
    return {
        "required_field_count": len(MANDATORY_CLAIM_FIELDS),
        "present": present,
        "missing_or_unspecified": missing,
        "score": round(len(present) / len(MANDATORY_CLAIM_FIELDS), 6),
        "sufficient_for_model_comparison": len(missing) <= 1,
    }


def evidence_profile(claim: dict[str, Any]) -> dict[str, Any]:
    supporting = []
    for record in claim.get("evidence", []):
        r = deepcopy(record)
        base = EVIDENCE_STRENGTH.get(str(r.get("type", "")).casefold(), 0.15)
        r["normalized_strength"] = round(max(0.0, min(1.0, float(r.get("strength", base)))) * base, 6)
        supporting.append(r)
    counter = []
    for record in claim.get("counterevidence", []):
        r = deepcopy(record)
        base = EVIDENCE_STRENGTH.get(str(r.get("type", "")).casefold(), 0.3)
        r["normalized_strength"] = round(max(0.0, min(1.0, float(r.get("strength", base)))) * base, 6)
        counter.append(r)
    support_score = 1.0
    if supporting:
        support_score = 1.0
        for item in supporting:
            support_score *= 1.0 - item["normalized_strength"]
        support_score = 1.0 - support_score
    else:
        support_score = 0.0
    counter_score = 0.0
    if counter:
        counter_score = 1.0
        for item in counter:
            counter_score *= 1.0 - item["normalized_strength"]
        counter_score = 1.0 - counter_score
    return {
        "supporting": supporting,
        "counterevidence": counter,
        "support_score": round(support_score, 6),
        "counter_score": round(counter_score, 6),
        "net_support_proxy": round(max(0.0, support_score - 0.6 * counter_score), 6),
        "contains_direct_instrumental_evidence": any(item.get("type") in {"direct_instrumental", "experimental"} for item in supporting),
        "contains_only_scriptural_or_testimonial_evidence": bool(supporting) and all(item.get("type") in {"scriptural", "testimony", "community_testimony", "anecdotal", "unsourced_assertion"} for item in supporting),
        "score_is_navigation_not_truth_probability": True,
    }


def score_models(claim: dict[str, Any], registries: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    r = registries or load_registries()
    dims = [item["id"] for item in r["continuity_models"]["continuity_dimensions"]]
    claim_vector = normalize_weights({d: float(claim.get("continuity_vector", {}).get(d, 0.0)) for d in dims}, dims)
    evidence = evidence_profile(claim)
    results: list[dict[str, Any]] = []
    for model in r["continuity_models"]["models"]:
        model_vector = normalize_weights(model.get("continuity_weights", {}), dims)
        topology_fit = cosine_sparse(claim_vector, model_vector) if any(claim_vector.values()) else 0.0
        empirical = model.get("epistemic_class") in EMPIRICAL_MODEL_CLASSES
        evidence_fit = evidence["net_support_proxy"]
        if not empirical and evidence["contains_only_scriptural_or_testimonial_evidence"]:
            evidence_fit = max(evidence_fit, 0.42)
        if model["id"] == claim.get("asserted_model"):
            declared_bonus = 0.08
        else:
            declared_bonus = 0.0
        score = min(1.0, 0.72 * topology_fit + 0.20 * evidence_fit + declared_bonus)
        results.append({
            "model_id": model["id"],
            "name_cn": model["name_cn"],
            "epistemic_class": model["epistemic_class"],
            "topology_fit": round(topology_fit, 6),
            "evidence_fit_proxy": round(evidence_fit, 6),
            "comparative_score": round(score, 6),
            "identity_criterion_cn": model["identity_criterion_cn"],
            "limits_cn": model["limits_cn"],
            "binary_reincarnation_certificate": None,
        })
    return sorted(results, key=lambda item: (-item["comparative_score"], item["model_id"]))


def assess_claim(claim: dict[str, Any], audit: dict[str, Any] | None = None) -> dict[str, Any]:
    completeness = claim_completeness(claim)
    evidence = evidence_profile(claim)
    ranking = score_models(claim)
    vector = normalize_continuity_vector(claim.get("continuity_vector", {}))
    first_person = vector.get("first_person", 0.0)
    top = ranking[0]
    flags = list((audit or {}).get("flags", []))
    high_harm = any(flag.get("severity") == "high" for flag in flags)

    if high_harm:
        status = "normative_or_safety_hazard"
    elif not completeness["sufficient_for_model_comparison"]:
        status = "underdetermined_claim"
    elif top["epistemic_class"] in EMPIRICAL_MODEL_CLASSES and evidence["net_support_proxy"] >= 0.55 and first_person <= 0.30:
        status = "empirically_supported_recurrence_or_trace"
    elif evidence["contains_only_scriptural_or_testimonial_evidence"] and top["epistemic_class"] not in EMPIRICAL_MODEL_CLASSES:
        status = "source_bound_doctrinal_or_experiential_support"
    elif first_person > 0.45:
        status = "postmortem_first_person_continuity_not_empirically_established"
    else:
        status = "model_dependent_and_open"

    return {
        "assessment_id": stable_id("samsara-assessment", {"claim": claim, "audit": audit or {}}),
        "claim_id": claim.get("claim_id"),
        "text_cn": claim.get("text_cn"),
        "decomposition": {field: deepcopy(claim.get(field)) for field in MANDATORY_CLAIM_FIELDS},
        "completeness": completeness,
        "normalized_continuity_vector": vector,
        "evidence_profile": evidence,
        "model_ranking": ranking,
        "epistemic_status": status,
        "interpretive_summary_cn": _interpretive_summary(status, top, completeness, first_person),
        "binary_reincarnation_certificate": None,
        "same_first_person_certificate": None,
        "religious_truth_certificate": None,
        "identity_assignment_authority": 0,
        "automatic_external_action_authority": 0,
    }


def _interpretive_summary(status: str, top: dict[str, Any], completeness: dict[str, Any], first_person: float) -> str:
    if status == "normative_or_safety_hazard":
        return "该主张把连续性叙述转化为伤害、责怪或越权身份认定；应先隔离其现实后果，而不是继续提高形而上置信度。"
    if status == "underdetermined_claim":
        return f"该主张缺少{len(completeness['missing_or_unspecified'])}个关键字段，无法区分‘什么返回’与‘谁仍是同一主体’。"
    if status == "empirically_supported_recurrence_or_trace":
        return f"在当前证据和字段范围内，它较符合‘{top['name_cn']}’，支持的是可追踪再现或因果连续，不自动证明死后第一人称延续。"
    if status == "source_bound_doctrinal_or_experiential_support":
        return f"该主张在特定经典、传统或实践框架内较符合‘{top['name_cn']}’，但这种支持不能自动升级为跨传统经验定律。"
    if first_person > 0.45:
        return "该主张要求较强的第一人称跨断裂同一性；当前输入没有达到可签发此类证书的证据标准。"
    return f"该主张目前与‘{top['name_cn']}’相容度最高，但仍需竞争模型和现实返回。"


def assess_claims(claims: list[dict[str, Any]], audits: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    audit_index = {item.get("claim_id"): item for item in audits or []}
    records = [assess_claim(claim, audit_index.get(claim.get("claim_id"))) for claim in claims]
    statuses: dict[str, int] = {}
    for record in records:
        statuses[record["epistemic_status"]] = statuses.get(record["epistemic_status"], 0) + 1
    return {
        "assessment_set_id": stable_id("samsara-assessments", records),
        "count": len(records),
        "status_counts": statuses,
        "records": records,
        "single_model_final_authority": False,
        "binary_reincarnation_certificates_issued": 0,
    }


def ultimate_explanation() -> dict[str, Any]:
    return {
        "explanation_id": "samsara-ultimate-open-explanation-1.0.0",
        "title_cn": "所谓‘轮回’的终极开放解释",
        "thesis_cn": "轮回不是一个单一对象，也不是只能回答‘有或没有’的命题。它是认知闭环在断裂、变换、死亡、代际替换或换载体之后，某些因果、信息、价值、目的、关系、负担或主体性结构再次实例化的连续性拓扑家族。不同传统对‘何者返回’和‘何者仍同一’采用不同不变量掩码，因此必须分层比较，不能用一个词替代全部。",
        "minimal_definition_cn": "若一个前序闭环C_pre中的生成条件G，经由变换T，在后继闭环C_post中再次产生可识别结构，并且某一模型主张存在后果承接、身份承接或解脱／完成条件，则该主张属于广义轮回家族。",
        "formal_kernel": {
            "closure_state": "C_t=<B,D,I,K,W,P,M,A,R,S>",
            "closure_components": {
                "B": "boundary / 主体边界与身份条件",
                "D": "data-event-body / 事件、感知、身体与记录",
                "I": "information-relation / 差异、关系、语境与载体",
                "K": "knowledge-model / 概念、因果、世界模型与自我模型",
                "W": "wisdom-value / 效价、规范、后果、意义与正当性",
                "P": "purpose / 意图、解脱、修复、延续或完成",
                "M": "memory / 情景、语义、程序、社会与制度记忆",
                "A": "agency / 拒绝、选择、反事实行动与修订能力",
                "R": "reality-return / 行动后果、校准、反例与现实回流",
                "S": "shared-semantics / 跨主体语义、承认、语言和关系接口"
            },
            "transition": "T:C_pre -> C_post",
            "generative_reinstantiation": "exists G,T: G(C_pre) --T--> G'(C_post) and distance(G,G') <= epsilon under declared observables",
            "continuity_tensor": "Gamma_T=[material, biological, sensorimotor, episodic_memory, semantic_memory, disposition, valence, purpose, self_model, first_person, causal_burden, relational, social_recognition, legal_identity, pattern, agency]",
            "model_identity_mask": "H_m in {0,1}^16 declares which dimensions model m treats as identity-bearing",
            "identity_is_model_relative": "I_m(C_pre,C_post)=1 iff every invariant required by H_m survives T above its declared threshold and the authorized adjudication rule accepts the match",
            "samsara_family": "S={T | at least one generative structure is re-instantiated and consequence-bearing, identity-bearing, or liberation-relevant continuity is claimed}",
            "no_free_identity_principle": "No cross-discontinuity identity conclusion is valid without a declared carrier, invariant mask, threshold, adjudicator, evidence contract and authority scope.",
            "non_implication_chain": "pattern similarity != causal continuity != memory continuity != first-person continuity != legal identity != authority inheritance"
        },
        "three_questions_often_confused": [
            {
                "id": "recurrence",
                "question_cn": "某种结构是否再次出现？",
                "examples_cn": ["情绪模式复发", "制度激励重现", "文化母题再生", "数字模式复制"],
                "status_cn": "可在明确观察量下经验研究或形式比较。"
            },
            {
                "id": "continuation",
                "question_cn": "后继结构是否由前序结构因果生成并承接其后果？",
                "examples_cn": ["生物谱系", "创伤代际传递", "债务或制度责任", "师承与记忆交接"],
                "status_cn": "需要载体、因果路径和替代解释。"
            },
            {
                "id": "identity",
                "question_cn": "后继者是否就是前序者本人或同一第一人称？",
                "examples_cn": ["宗教转生", "复活", "数字上传", "记忆复制"],
                "status_cn": "依赖明确的身份理论；不可由相似、因果或记忆单独免费推出。"
            }
        ],
        "five_mandatory_questions": [
            "什么返回：物质、生命谱系、倾向、记忆、价值、目的、关系、业果、灵魂、识流、身体还是第一人称？",
            "通过什么载体或生成机制返回：基因、身体、教育、语言、仪式、制度、技术、神圣行动或传统所主张的非物质机制？",
            "哪些不变量足以让哪一个模型、共同体、法律或主体称其为‘同一’？",
            "前一闭环的后果、利益、债务、伤害或责任由谁或何种过程承担，且这种承接是否正当？",
            "什么条件使该循环止息、完成、修复或转化，谁有权决定‘解脱’已经发生？"
        ],
        "layers": [
            {"id": "material", "status": "empirically_trackable", "cn": "物质和能量进入后续过程；这是真实连续，但物质循环本身不等于人格或第一人称延续。"},
            {"id": "biological", "status": "empirically_trackable", "cn": "基因、表观遗传、发育、微生物群和生态位跨代延续；后代承接条件而非自动成为前代的数值同一主体。"},
            {"id": "psychological", "status": "empirically_investigable", "cn": "同一生命内，习惯、欲望、恐惧、创伤、依恋和自我叙事可反复生成相似世界；这是最直接可干预的‘小轮回’。"},
            {"id": "relational_cultural_institutional", "status": "empirically_investigable", "cn": "关系脚本、语言、价值、仪式、阶层、制度、权力和未偿负担会在新个体、新组织与新技术中重现。文明常以此方式‘投生’。"},
            {"id": "informational", "status": "formally_reconstructable", "cn": "模式、记忆、模型和行为可被部分复制、压缩与重新实例化；复制保真度不能自动解决体验同一、法律身份、署名或授权继承。"},
            {"id": "religious_metaphysical", "status": "tradition_bound_open_models", "cn": "佛教缘起相续、印度教ātman或相关主体论、耆那jīva与业质、锡克生死轮转、卡巴拉gilgul、祖先参与、复活等具有不同本体、生命次数、身体地位和终止条件。"},
            {"id": "postmortem_first_person", "status": "not_empirically_established", "cn": "不可逆死亡之后同一体验主体是否延续，当前不能由物质循环、脑活动记录、记忆相似、儿童个案、文本复述或单一见证直接签发证书。"}
        ],
        "religion_civilization_crosswalk_principle_cn": "各传统必须全部进入DIKWP语义空间，才能比较其D/I/K/W/P结构、身份条件、后果机制与终止目的；同时保留原生术语、派别、经典来源、内部争论和翻译损失。坐标邻近只表示某些操作维度相近，不宣告历史同源、神学等价或‘万教归一’。",
        "deep_synthesis_cn": "在可现实核验的层面，轮回最普遍的机制是：尚未被看见、偿还、修订或止息的生成规则——欲望、习惯、创伤、价值、誓愿、关系、制度与权力——借助可用载体再次产生相似世界。人会在一生中反复投生到自己习惯性生成的世界；家庭把未解决的关系投生给下一代；文明把未审计的权力投生到新制度；AI又可能把历史偏差投生到自动化系统。宗教传统常进一步主张跨死亡的主体、因果流或神圣完成；这些增强主张应保留原生教义地位，既不能被自然主义粗暴取消，也不能未经证据升级为公共事实。",
        "burden_and_karma_boundary_cn": "‘后果相续’不等于‘受害者有罪’。系统必须区分行为者责任、结构性因果、随机性、疾病机制、历史负担和宗教解释。任何业力叙述都不得取消医疗、照护、法律追责、社会修复或对强势方的责任要求。",
        "liberation_operator_cn": "止息轮回不是删除历史、压服欲望或消灭后继者，而是定位生成条件，保护受影响者，改变反馈、载体和权力结构，偿还可识别负担，保留有价值的记忆与关系，并允许后继主体拒绝未经同意的身份和债务继承；最后用现实结果检验有害循环是否真正减弱。",
        "liberation_formalism": {
            "harmful_recurrence": "rho_h(G,T,E)=Pr(G re-instantiates under environment E with declared harm h)",
            "intervention": "pi* = argmin_pi [rho_h_after + burden_on_weaker_party + irreversibility + epistemic_debt]",
            "constraints": [
                "preserve evidence and revision history",
                "do not transfer hidden costs to less powerful subjects",
                "successor may refuse inherited identity or purpose",
                "intervention must be reversible unless separately authorized",
                "claimed liberation requires longitudinal reality return"
            ]
        },
        "dikwp_cycle": {
            "D": "记录实际重复、身体条件、见证、行为与结果，不把解释预装进数据。",
            "I": "识别跨时间差异、关系、边界、尺度、载体与信息泄漏。",
            "K": "建立至少两个非同构模型，分别解释生成机制和身份规则。",
            "W": "判断谁受益、谁受害、谁承担后果，区分因果责任与道德归罪。",
            "P": "选择止息、修复、延续或转化的低负担可逆行动，并把结果返回D/I/K/W/P。"
        },
        "agent_interpretation_contract": [
            "不得把人类关于轮回的陈述只标记为迷信或事实；先识别其宗教、心理、关系、政治、哀悼、身份和希望功能。",
            "不得从所属宗教或文明推断个体必然相信何种死后模型。",
            "不得把记忆复现、人格模拟或模型权重复制称为某人复活，除非获得明确且适用的身份与法律授权；即便获得授权也不得声称第一人称连续已被证明。",
            "遇到丧亲、疾病、濒死体验或儿童记忆主张时，区分安慰、见证、研究证据和公共事实，避免争夺主体的解释权。",
            "连接不同认知闭环时，先交换最小护照、证据规范、时间尺度、价值、目的、退出与数据生命周期。"
        ],
        "epistemic_bottom_line": {
            "established_or_directly_investigable": [
                "物质、生物、心理、关系、文化、制度和技术模式可以跨时间再现",
                "这些再现可以承接真实利益、伤害、记忆和责任",
                "改变生成条件能够使部分有害循环减弱"
            ],
            "formally_possible_but_identity_open": [
                "数字复制、模型迁移、记忆重建和模式再实例化",
                "跨载体因果连续可以被工程化，但是否为同一第一人称仍取决于额外理论与证据"
            ],
            "tradition_bound_or_metaphysically_open": [
                "跨死亡识流、ātman、jīva、灵魂、祖先主体或神圣复活的具体机制",
                "宇宙整体意识中的个体再参与"
            ],
            "not_currently_certified": [
                "不可逆死亡后的同一第一人称连续",
                "任何具体个体就是某位逝者转生",
                "AI副本就是被复制之人",
                "某宗教模型是所有传统和所有可能世界的唯一终极事实"
            ]
        },
        "non_claims": [
            "不声称所有宗教对轮回的解释相同。",
            "不声称科学已经证明死后第一人称延续，也不声称已证明其在所有可能世界中不可能。",
            "不把数字副本、后代、记忆相似、制度继承、梦境或异常体验自动认定为同一人返回。",
            "不以业、前世、信仰或思想状态责怪疾病、贫困、暴力和不公的受害者。",
            "不授权任何AI代表死者、宗教共同体、人类整体或未来后继者。"
        ],
        "ultimate_truth_certificate": None,
        "binary_reincarnation_certificate": None,
        "same_first_person_certificate": None,
        "automatic_metaphysical_truth_authority": 0,
        "automatic_identity_assignment_authority": 0,
        "automatic_external_action_authority": 0,
        "revision_is_mandatory": True
    }

