from __future__ import annotations

from datetime import datetime, timezone
from html import escape as html_escape
from importlib.resources import files
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence
import hashlib
import json
import math
import re
import unicodedata


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def sha256_obj(obj: Any) -> str:
    return sha256_text(canonical_json(obj))


def stable_id(prefix: str, obj: Any, length: int = 20) -> str:
    return f"{prefix}-{sha256_obj(obj)[:length]}"


def normalize_text(text: Any) -> str:
    value = unicodedata.normalize("NFKC", str(text or ""))
    value = value.replace("\u00a0", " ")
    value = re.sub(r"[\t\r ]+", " ", value)
    value = re.sub(r"\n{3,}", "\n\n", value)
    return value.strip()


def load_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save_json(path: str | Path, obj: Any) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    return str(p)


def save_text(path: str | Path, text: str) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")
    return str(p)


def load_bundled_json(name: str) -> Any:
    resource = files("dikwp_samsara95.data").joinpath(name)
    return json.loads(resource.read_text(encoding="utf-8"))


def clamp(value: Any, low: float = 0.0, high: float = 1.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return low
    return max(low, min(high, number))


def mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def normalize_weights(weights: dict[str, float], allowed: Iterable[str] | None = None) -> dict[str, float]:
    keys = list(allowed) if allowed is not None else list(weights)
    cleaned = {k: max(0.0, float(weights.get(k, 0.0))) for k in keys}
    total = sum(cleaned.values())
    if total <= 0:
        return {k: 0.0 for k in keys}
    return {k: v / total for k, v in cleaned.items()}


def cosine_sparse(a: dict[str, float], b: dict[str, float]) -> float:
    keys = set(a) | set(b)
    dot = sum(float(a.get(k, 0.0)) * float(b.get(k, 0.0)) for k in keys)
    na = math.sqrt(sum(float(a.get(k, 0.0)) ** 2 for k in keys))
    nb = math.sqrt(sum(float(b.get(k, 0.0)) ** 2 for k in keys))
    return dot / (na * nb) if na and nb else 0.0


def l1_distance(a: dict[str, float], b: dict[str, float]) -> float:
    keys = set(a) | set(b)
    return sum(abs(float(a.get(k, 0.0)) - float(b.get(k, 0.0))) for k in keys)


def geometric_compatibility(a: float, b: float) -> float:
    a = max(1e-9, float(a))
    b = max(1e-9, float(b))
    ratio = min(a, b) / max(a, b)
    return math.sqrt(ratio)


def html(value: Any) -> str:
    return html_escape(str(value if value is not None else ""), quote=True)


def iter_files(root: str | Path, exclude_names: set[str] | None = None) -> Iterator[Path]:
    base = Path(root)
    excluded = exclude_names or set()
    for path in sorted(base.rglob("*")):
        if path.is_file() and path.name not in excluded:
            yield path


def manifest_for(root: str | Path, exclude_names: set[str] | None = None) -> dict[str, Any]:
    base = Path(root)
    excluded = (exclude_names or set()) | {"MANIFEST.json", "VERIFY.txt"}
    records: list[dict[str, Any]] = []
    for path in iter_files(base, excluded):
        records.append({
            "path": path.relative_to(base).as_posix(),
            "bytes": path.stat().st_size,
            "sha256": sha256_bytes(path.read_bytes()),
        })
    result = {"algorithm": "sha256", "file_count": len(records), "files": records}
    result["manifest_digest"] = sha256_obj(result)
    return result


def family_vector(vector: dict[str, float]) -> dict[str, float]:
    result = {"D": 0.0, "I": 0.0, "K": 0.0, "W": 0.0, "P": 0.0}
    for key, value in vector.items():
        family = key.split(".", 1)[0]
        if family in result:
            result[family] += float(value)
    return normalize_weights(result, result.keys())


def deep_without(obj: dict[str, Any], *keys: str) -> dict[str, Any]:
    result = dict(obj)
    for key in keys:
        result.pop(key, None)
    return result
