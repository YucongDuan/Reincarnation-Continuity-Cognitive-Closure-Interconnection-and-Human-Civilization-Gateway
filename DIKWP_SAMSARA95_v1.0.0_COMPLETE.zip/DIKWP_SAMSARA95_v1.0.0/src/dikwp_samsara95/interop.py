from __future__ import annotations

from copy import deepcopy
from typing import Any

from .continuity import ultimate_explanation
from .civilization import build_human_civilization_gateway, to_jsonld
from .registries import load_registries


MCP_PROTOCOL_VERSION = "2026-07-28"
A2A_PROTOCOL_VERSION = "1.0"


def mcp_tools() -> list[dict[str, Any]]:
    return [
        {
            "name": "explain_reincarnation",
            "title": "Explain reincarnation as continuity topologies",
            "description": "Return the layered DIKWP-SAMSARA95 explanation without issuing metaphysical truth or identity certificates.",
            "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
            "annotations": {"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        },
        {
            "name": "assess_continuity_claim",
            "title": "Assess a continuity or reincarnation claim",
            "description": "Decompose a claim into carrier, identity, consequence and exit fields; compare non-isomorphic models.",
            "inputSchema": {
                "type": "object",
                "required": ["claim"],
                "properties": {"claim": {"type": "object"}},
                "additionalProperties": False,
            },
            "annotations": {"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        },
        {
            "name": "get_human_civilization_gateway",
            "title": "Read the plural human-civilization gateway",
            "description": "Return the 22-lens machine-readable gateway for interpreting contemporary humans without stereotyping or hidden profiling.",
            "inputSchema": {
                "type": "object",
                "properties": {"query": {"type": "string"}, "limit": {"type": "integer", "minimum": 1, "maximum": 22}},
                "additionalProperties": False,
            },
            "annotations": {"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        },
        {
            "name": "bridge_cognitive_closures",
            "title": "Build a bridge between two cognitive closures",
            "description": "Compare declared interfaces and produce safe questions, losses and asymmetry protections without declaring identity equivalence.",
            "inputSchema": {
                "type": "object",
                "required": ["passportA", "passportB"],
                "properties": {"passportA": {"type": "object"}, "passportB": {"type": "object"}},
                "additionalProperties": False,
            },
            "annotations": {"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        },
        {
            "name": "build_interclosure_handshake",
            "title": "Build a reversible inter-closure handshake",
            "description": "Return a proposal-only, consent-explicit handshake. It never authorizes a connection or external action.",
            "inputSchema": {
                "type": "object",
                "required": ["passportA", "passportB"],
                "properties": {"passportA": {"type": "object"}, "passportB": {"type": "object"}},
                "additionalProperties": False,
            },
            "annotations": {"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        },
        {
            "name": "map_tradition_continuity",
            "title": "Read a source-bound tradition continuity mapping",
            "description": "Return one of 36 tradition-level mappings in the shared DIKWP space while preserving doctrinal non-equivalence.",
            "inputSchema": {
                "type": "object",
                "required": ["traditionId"],
                "properties": {"traditionId": {"type": "string"}},
                "additionalProperties": False,
            },
            "annotations": {"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
        },
    ]


def build_mcp_manifest() -> dict[str, Any]:
    return {
        "profile": "DIKWP-SAMSARA95 read-only MCP reference adapter",
        "protocolVersion": MCP_PROTOCOL_VERSION,
        "transport": "stdio newline-delimited JSON-RPC 2.0",
        "stateless": True,
        "supportedMethods": ["server/discover", "tools/list", "tools/call", "resources/list", "resources/read"],
        "tools": mcp_tools(),
        "security": {
            "readOnly": True,
            "humanMayDenyInvocation": True,
            "secretsInOutput": False,
            "automaticExternalActionAuthority": 0,
        },
        "conformance_status": "reference_subset_not_independently_certified",
    }


def build_a2a_agent_card(endpoint: str = "https://example.invalid/dikwp-samsara95/a2a") -> dict[str, Any]:
    return {
        "name": "DIKWP-SAMSARA95 Human–Civilization Gateway",
        "description": "Read-only reference agent profile for continuity-claim analysis, cognitive-closure bridging and plural human-civilization interpretation. It never issues metaphysical truth, consciousness, reincarnation or identity certificates and never authorizes external action.",
        "supportedInterfaces": [
            {"url": endpoint, "protocolBinding": "HTTP+JSON", "protocolVersion": A2A_PROTOCOL_VERSION}
        ],
        "provider": {"organization": "Yucong Duan / OpenAI-assisted open-source reference implementation", "url": "https://github.com/YucongDuan"},
        "version": "1.0.0",
        "documentationUrl": "https://github.com/YucongDuan",
        "capabilities": {"streaming": False, "pushNotifications": False, "extendedAgentCard": False},
        "defaultInputModes": ["application/json", "text/plain"],
        "defaultOutputModes": ["application/json", "text/plain"],
        "skills": [
            {
                "id": "explain-reincarnation-topologies",
                "name": "Explain reincarnation topologies",
                "description": "Separates material, biological, psychological, cultural, informational, religious and first-person continuity claims.",
                "tags": ["DIKWP", "reincarnation", "continuity", "religion", "identity"],
                "examples": ["Explain what can mean the same person returns", "Compare rebirth and resurrection"],
                "inputModes": ["text/plain", "application/json"],
                "outputModes": ["application/json", "text/plain"],
            },
            {
                "id": "bridge-cognitive-closures",
                "name": "Bridge cognitive closures",
                "description": "Produces a consent-explicit, reversible protocol between a human, AI agent, collective or other declared subject interface.",
                "tags": ["cognitive-closure", "consent", "interop", "Mesh95"],
                "examples": ["Bridge this human passport and this agent passport"],
                "inputModes": ["application/json"],
                "outputModes": ["application/json"],
            },
            {
                "id": "read-human-civilization-gateway",
                "name": "Read human civilization gateway",
                "description": "Provides 22 plural lenses and anti-stereotyping rules for AI or agents interpreting present human life and institutions.",
                "tags": ["humanity", "civilization", "culture", "rights", "AI-ethics"],
                "examples": ["What should an agent know before interpreting human consent?"],
                "inputModes": ["text/plain", "application/json"],
                "outputModes": ["application/json", "text/plain"],
            },
        ],
    }


def build_openapi() -> dict[str, Any]:
    return {
        "openapi": "3.1.0",
        "info": {
            "title": "DIKWP-SAMSARA95 Read-only Gateway API",
            "version": "1.0.0",
            "description": "Local reference API. All endpoints are analytical and issue no identity, metaphysical or action authority.",
        },
        "servers": [{"url": "http://127.0.0.1:8765"}],
        "paths": {
            "/health": {"get": {"operationId": "health", "responses": {"200": {"description": "Healthy"}}}},
            "/v1/reincarnation/explanation": {"get": {"operationId": "explainReincarnation", "responses": {"200": {"description": "Layered explanation"}}}},
            "/v1/civilization/pack": {"get": {"operationId": "getCivilizationPack", "responses": {"200": {"description": "Plural human-civilization gateway"}}}},
            "/v1/claims/assess": {
                "post": {
                    "operationId": "assessContinuityClaim",
                    "requestBody": {"required": True, "content": {"application/json": {"schema": {"type": "object"}}}},
                    "responses": {"200": {"description": "Continuity assessment"}},
                }
            },
            "/v1/closures/bridge": {
                "post": {
                    "operationId": "bridgeCognitiveClosures",
                    "requestBody": {"required": True, "content": {"application/json": {"schema": {"type": "object"}}}},
                    "responses": {"200": {"description": "Bridge analysis"}},
                }
            },
            "/v1/closures/handshake": {
                "post": {
                    "operationId": "buildHandshake",
                    "requestBody": {"required": True, "content": {"application/json": {"schema": {"type": "object"}}}},
                    "responses": {"200": {"description": "Proposal-only handshake"}},
                }
            },
            "/.well-known/agent-card.json": {"get": {"operationId": "agentCard", "responses": {"200": {"description": "A2A v1.0 profile card"}}}},
        },
        "x-samsara95": {
            "automaticExternalActionAuthority": 0,
            "identityCertificate": None,
            "metaphysicalTruthCertificate": None,
            "referenceImplementation": True,
        },
    }


def build_interop_bundle() -> dict[str, Any]:
    gateway = build_human_civilization_gateway()
    return {
        "jsonld": to_jsonld(gateway),
        "a2aAgentCard": build_a2a_agent_card(),
        "a2aProfileStatus": {
            "protocolVersion": A2A_PROTOCOL_VERSION,
            "profileOnly": True,
            "runningA2AServerIncluded": False,
            "independentConformanceCertification": False,
        },
        "mcpToolManifest": build_mcp_manifest(),
        "openapi": build_openapi(),
        "automaticExternalActionAuthority": 0,
    }
