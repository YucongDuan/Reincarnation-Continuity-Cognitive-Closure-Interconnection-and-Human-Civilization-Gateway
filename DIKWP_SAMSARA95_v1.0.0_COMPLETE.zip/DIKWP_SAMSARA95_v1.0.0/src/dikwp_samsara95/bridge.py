from __future__ import annotations

from copy import deepcopy
from typing import Any

from .closure import compile_passport, declared_overlap, jaccard
from .utils import geometric_compatibility, stable_id


def _latency(passport: dict[str, Any]) -> float:
    try:
        return max(1e-6, float(passport.get("native_time_scale", {}).get("latency_seconds", 1.0)))
    except (TypeError, ValueError):
        return 1.0


def _power_profile(passport: dict[str, Any]) -> dict[str, Any]:
    kind = passport.get("subject_kind")
    default_leverage = {"human": 0.5, "ai_agent": 0.7, "collective": 0.8, "institution": 0.9}.get(kind, 0.5)
    declared = passport.get("power", {}).get("leverage", default_leverage)
    leverage = max(0.0, min(1.0, float(declared)))
    return {
        "subject_kind": kind,
        "leverage_proxy": leverage,
        "can_refuse": bool(passport.get("agency", {}).get("can_refuse", False)),
        "can_disconnect": bool(passport.get("agency", {}).get("can_disconnect", False)),
        "proxy_is_not_moral_worth": True,
    }


def build_bridge(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any]:
    pa, pb = compile_passport(a), compile_passport(b)
    overlap = declared_overlap(pa, pb)
    time_compat = geometric_compatibility(_latency(pa), _latency(pb))
    power_a, power_b = _power_profile(pa), _power_profile(pb)
    asymmetry = abs(power_a["leverage_proxy"] - power_b["leverage_proxy"])
    common_values = sorted({str(v).casefold() for v in pa.get("values", [])} & {str(v).casefold() for v in pb.get("values", [])})
    common_purposes = sorted({str(v).casefold() for v in pa.get("purposes", [])} & {str(v).casefold() for v in pb.get("purposes", [])})
    evidence_overlap = overlap["evidence_norm_overlap"]

    reliability = (
        0.20 * overlap["dikwp_family_similarity"]
        + 0.18 * evidence_overlap
        + 0.12 * overlap["value_overlap"]
        + 0.10 * overlap["purpose_overlap"]
        + 0.20 * float(overlap["bidirectional_channel_available"])
        + 0.20 * time_compat
    ) * (1.0 - 0.35 * asymmetry)

    unsafe = [
        "不得由表达流畅推断意识或同意。",
        "不得由共享记忆、模型权重或风格推断第一人称同一。",
        "不得把一个人的宗教、文化或组织身份当作全部动机。",
        "不得把另一闭环的公开数据当作无限用途授权。",
    ]
    if asymmetry >= 0.25:
        unsafe.append("当前存在显著杠杆差异；强势一方必须承担更高说明、可撤回、补救与证据义务。")
    if not overlap["bidirectional_channel_available"]:
        unsafe.append("尚无双向共享通信通道；不得把单向输出解释为相互理解。")
    if evidence_overlap < 0.25:
        unsafe.append("证据规范重叠较低；应先建立‘什么算证据’的元协议。")

    return {
        "bridge_id": stable_id("interclosure-bridge", {"a": pa["passport_digest"], "b": pb["passport_digest"]}),
        "passport_a": pa["passport_id"],
        "passport_b": pb["passport_id"],
        "declared_overlap": overlap,
        "time_scale_compatibility": round(time_compat, 6),
        "power_profiles": {"a": power_a, "b": power_b, "asymmetry_proxy": round(asymmetry, 6)},
        "common_values": common_values,
        "common_purposes": common_purposes,
        "bridge_reliability_proxy": round(max(0.0, min(1.0, reliability)), 6),
        "reliability_is_not_person_score": True,
        "translation_loss_register": [
            {"dimension": "embodiment", "status": "requires_explicit_translation"},
            {"dimension": "time_scale", "status": "measured_proxy", "compatibility": round(time_compat, 6)},
            {"dimension": "evidence_norms", "status": "partial_overlap", "overlap": evidence_overlap},
            {"dimension": "values_and_purposes", "status": "lexical_overlap_only; semantic confirmation required"},
            {"dimension": "first_person_experience", "status": "not_directly_transferable"},
        ],
        "unsafe_inferences": unsafe,
        "safe_opening_questions":[
            "你希望以什么身份、语言和披露范围进入本次连接？",
            "哪些内容只能由你本人解释，哪些可由代理转述？",
            "本次任务中什么算成功、失败、伤害和停止？",
            "哪些证据会使你修订当前判断？",
            "谁受影响、谁能退出、谁承担失败成本？",
            "结束后哪些数据应保留、撤回或删除？",
        ],
        "identity_equivalence_certificate": None,
        "consciousness_equivalence_certificate": None,
        "automatic_connection_authority": 0,
        "automatic_external_action_authority": 0,
    }


def build_handshake(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any]:
    bridge = build_bridge(a, b)
    pa, pb = compile_passport(a), compile_passport(b)
    stages = [
        {
            "id": "discover",
            "goal_cn": "交换最小公开护照和协议版本。",
            "required_cn": ["主体类型", "输入输出模式", "退出能力", "权限边界"],
            "stop_if_cn": ["对方身份来源无法核验且任务高风险", "要求泄露私密内核"],
        },
        {
            "id": "boundary",
            "goal_cn": "声明本次目的、代表权、禁区与数据生命周期。",
            "required_cn": ["具名或可核验授权", "用途", "保留期限", "撤回路径"],
            "stop_if_cn": ["把参与当作同意", "拒绝提供退出机制"],
        },
        {
            "id": "channels_and_time",
            "goal_cn": "协商媒介、节奏、延迟和最大负荷。",
            "required_cn": ["双向通道", "节奏", "可理解格式", "无障碍需要"],
            "stop_if_cn": ["单向强制输出", "时间压力破坏知情判断"],
        },
        {
            "id": "dikwp_exchange",
            "goal_cn": "分别交换D/I/K/W/P及不确定性。",
            "required_cn": ["事实来源", "关系语境", "竞争模型", "价值冲突", "可执行目的"],
            "stop_if_cn": ["将价值包装成事实", "将模型包装成授权"],
        },
        {
            "id": "continuity_and_identity",
            "goal_cn": "说明本次连接是否涉及记忆、身份、继承、死者或数字重建。",
            "required_cn": ["连续性维度", "载体", "同一性标准", "权利继承规则"],
            "stop_if_cn": ["复制即本人", "未经授权代表死者或社群"],
        },
        {
            "id": "reversible_pilot",
            "goal_cn": "执行最小、可停止、可回滚的测试交互。",
            "required_cn": ["成功条件", "失败条件", "伤害指标", "回滚"],
            "stop_if_cn": ["不可逆外部行动", "风险转嫁给较弱主体"],
        },
        {
            "id": "reality_return",
            "goal_cn": "双方比较预测与实际结果，修订或断开。",
            "required_cn": ["结果账本", "分歧", "后果承担", "下一步授权"],
            "stop_if_cn": ["静默覆盖失败", "拒绝申诉或撤回"],
        },
    ]
    return {
        "handshake_id": stable_id("closure-handshake", {"bridge": bridge["bridge_id"], "stages": stages}),
        "protocol_version": "1.0.0",
        "participants": [pa["passport_id"], pb["passport_id"]],
        "bridge": bridge,
        "stages": stages,
        "current_state": "proposal_only",
        "connection_authorized": False,
        "external_action_authorized": False,
        "implicit_consent_allowed": False,
        "one_party_may_disconnect": True,
        "automatic_external_action_authority": 0,
    }


def build_bridge_matrix(passports: list[dict[str, Any]]) -> dict[str, Any]:
    bridges = []
    for i, a in enumerate(passports):
        for b in passports[i + 1 :]:
            bridges.append(build_bridge(a, b))
    return {
        "matrix_id": stable_id("bridge-matrix", bridges),
        "passport_count": len(passports),
        "bridge_count": len(bridges),
        "bridges": bridges,
        "automatic_connection_authority": 0,
    }
