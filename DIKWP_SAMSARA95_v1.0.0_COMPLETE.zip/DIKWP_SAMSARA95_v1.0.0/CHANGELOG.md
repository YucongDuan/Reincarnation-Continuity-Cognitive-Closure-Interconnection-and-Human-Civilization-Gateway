# Changelog

## 1.0.0 — 2026-09-01

- Introduced the 16-dimensional continuity tensor and 11 non-isomorphic models.
- Added the five-question decomposition of reincarnation claims.
- Added 36 source-bound tradition mappings and 144 native concepts in one DIKWP semantic space without doctrinal-equivalence claims.
- Added seven-stage cognitive-closure handshake and all-pairs demo bridge matrix.
- Added 22-lens plural human-civilization gateway for AI/agents.
- Added claim auditing, evidence profiling, identity/authority separation and victim-blaming safeguards.
- Added JSON-LD, A2A v1.0 profile, MCP 2026-07-28 read-only stdio adapter, local OpenAPI gateway, schemas, tests and reproducible release validation.
