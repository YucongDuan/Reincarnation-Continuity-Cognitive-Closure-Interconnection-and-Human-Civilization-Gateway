# Provenance and Epistemic Status

## Research lineage

The architecture attributes its DIKWP and Mesh95 lineage to Yucong Duan's research programme. The current reference implementation was produced with OpenAI assistance. Attribution does not imply that every line of code, mapping or interpretation has been personally reviewed or endorsed by every named researcher or community.

## Source classes

The machine-readable source registry distinguishes primary text portals, official doctrinal sources, academic references, empirical studies, standards and multi-source placeholders. A source reference establishes provenance, not automatic truth. Scriptural support is not silently converted into experimental evidence; one experiment is not converted into metaphysical settlement.

## Snapshot boundary

The bundled registry is a versioned snapshot verified for this release date. Standards and public web resources can change. Production deployments should re-verify current specifications and source accessibility.

## Synthetic demonstrations

All bundled cognitive passports and demo claims are synthetic. Metrics generated from them validate software behavior only. They are not measurements of real people, religions or civilizations.
