# Release Notes — v1.0.0

This is the first public reference release of DIKWP-SAMSARA95. It is an analytical and interoperability system, not a metaphysical oracle or identity adjudicator.

The bundled data and demonstrations are research-oriented snapshots dated 2026-09-01. Synthetic passports and claims are explicitly marked as such. Users should replace placeholder and multi-source records with source-specific, community-reviewed material for high-impact deployment.

All external-action and status-assignment authorities are zero by design.
