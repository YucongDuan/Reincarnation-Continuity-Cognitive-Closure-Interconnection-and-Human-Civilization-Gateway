# DIKWP-SAMSARA 9.5 发布索引

## 首要入口

- `README_CN.md`：系统总览与最短运行路径；
- `outputs/samsara_demo/REINCARNATION_ULTIMATE_EXPLANATION_CN.md`：所谓“轮回”的分层解释；
- `outputs/samsara_demo/FULL_SYSTEM_REPORT_CN.md`：完整系统报告；
- `outputs/samsara_demo/dashboard.html`：完全离线的可视化审阅页；
- `outputs/samsara_demo/samsara_bundle.json`：机器可读总包；
- `RELEASE_VALIDATION.json`：发布前验证边界。

## 开发入口

- `src/dikwp_samsara95/`：Python参考实现；
- `src/dikwp_samsara95/data/`：模型、传统、来源、治理、人类文明和演示注册表；
- `schemas/`：认知闭环、连续性主张、桥接、文明透镜和总包Schema；
- `tests/`：单元、集成、Schema、CLI、互操作和篡改检测测试；
- `examples/`：护照、主张和MCP请求；
- `docs/`：理论、架构、宗教文明、AI网关、研究、安全和部署说明；
- `dist/`：Python wheel。

## 互操作产物

- `outputs/samsara_demo/human_civilization_gateway.jsonld`；
- `outputs/samsara_demo/a2a_agent_card.json`；
- `outputs/samsara_demo/mcp_tool_manifest.json`；
- `outputs/samsara_demo/openapi.json`；
- `src/dikwp_samsara95/mcp_stdio.py`；
- `src/dikwp_samsara95/server.py`。

所有互操作产物均为分析和读取接口，不生成意识、灵魂、身份、宗教真理、法律人格或外部行动授权。
