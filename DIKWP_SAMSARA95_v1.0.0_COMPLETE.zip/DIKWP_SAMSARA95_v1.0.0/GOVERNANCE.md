# Governance

DIKWP-SAMSARA95 follows Mesh95 responsibility closure.

## Decision priorities

1. Factual traceability and explicit uncertainty.
2. Protection of subjects exposed to higher power, cost, surveillance, stigma or irreversibility.
3. No silent expansion of consent, identity, representation or authority.
4. Preservation of source, branch, dissent, translation loss and revision history.
5. At least two non-isomorphic models for high-impact claims.
6. Named, scoped and revocable authorization before any downstream system performs external action.
7. Successor freedom: a descendant, copy, student, institution or agent may reject inherited identity, debt, purpose and representation.

## Change control

Changes to identity criteria, evidence weights, tradition mappings, human-civilization lenses, authority fields or public interfaces require a versioned proposal, impact analysis, tests and release notes. No maintainer may convert a null metaphysical or identity certificate into an asserted status merely by code change.

## Community and tradition mappings

Mapped communities retain authority over their living self-description. Repository inclusion is not endorsement, ownership, representation or doctrinal settlement. Corrections should preserve the previous version and document the reason for revision.
