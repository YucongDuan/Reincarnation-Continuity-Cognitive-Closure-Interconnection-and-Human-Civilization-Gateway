# Security Policy

## Supported version

Version 1.0.x receives security fixes in this reference line.

## Security invariants

- The HTTP server binds only to loopback addresses.
- The MCP adapter is read-only and stateless.
- Request bodies are size limited.
- No endpoint sends messages, publishes content, operates devices, modifies identities, or performs transactions.
- A cognitive passport is selective-disclosure interface data, not a license for profiling.
- Secrets and private memories must not be placed in public passports or bug reports.

## Reporting

Report vulnerabilities privately to the repository maintainer. Include reproduction steps, affected version, impact, and a minimal safe proof. Do not include real medical, religious-confession, minor, deceased-person, or private identity data.
