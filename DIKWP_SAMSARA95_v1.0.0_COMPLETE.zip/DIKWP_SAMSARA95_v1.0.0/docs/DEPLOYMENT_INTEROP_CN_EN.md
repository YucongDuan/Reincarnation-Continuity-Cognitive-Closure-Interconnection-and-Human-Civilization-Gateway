# 部署与互操作 / Deployment and Interoperability

## Local CLI

```bash
samsara95 doctor
samsara95 demo --out outputs/samsara_demo
samsara95 verify outputs/samsara_demo
```

## MCP stdio

```bash
samsara95 mcp
```

Messages are newline-delimited JSON-RPC 2.0. `server/discover` may probe supported versions; other requests must carry `io.modelcontextprotocol/protocolVersion=2026-07-28` in `params._meta`. The adapter is stateless and read-only.

## HTTP

```bash
samsara95 serve --host 127.0.0.1 --port 8765
```

The reference server rejects non-loopback binding. It is not production hardened. Add authentication, TLS, rate limiting, audit logging, deployment-specific privacy review and current protocol validation before any network deployment.

## A2A profile

`a2a_agent_card.json` is a capability profile using the v1.0 field family; it is not an independently certified or deployed A2A server. Replace the invalid placeholder endpoint only after a secure implementation exists.

## Semantic boundary

Protocol success means messages were exchanged under the declared schema. It does not prove equivalent meaning, shared consciousness, valid consent or authority.
