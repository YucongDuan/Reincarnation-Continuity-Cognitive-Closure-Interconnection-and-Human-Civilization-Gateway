# 形式理论 / Formal Theory

## 1. Continuity claim

A claim is represented as:

```text
Q=<C_pre,C_post,T,X,H,Theta,J,Burden,Exit,E+,E-,F,U>
```

where `X` is the carrier, `H` the invariant mask, `Theta` thresholds, `J` the identity adjudication rule, `Burden` consequence transfer, `Exit` the completion condition, `E+` evidence, `E-` counterevidence, `F` falsifiers and `U` uncertainty.

## 2. Sixteen-dimensional tensor

```text
Gamma_T = [
 material, biological, sensorimotor,
 episodic_memory, semantic_memory, disposition,
 valence, purpose, self_model, first_person,
 causal_burden, relational, social_recognition,
 legal_identity, pattern, agency
]
```

The tensor describes declared continuity strength; it is not a truth probability and does not sum disparate concepts into one soul score.

## 3. Model-relative identity

```text
I_m(C_pre,C_post)=1
iff
for every dimension required by H_m,
continuity exceeds Theta_m,
the causal/interpretive conditions of model m hold,
and the authorized adjudicator accepts the match.
```

This makes identity explicit rather than free. Different models can disagree without one silently replacing the other.

## 4. Non-implications

```text
pattern match -/-> causal descent
causal descent -/-> episodic memory
memory match -/-> first-person identity
first-person claim -/-> legal identity
legal identity -/-> authorization inheritance
religious source support -/-> experimental establishment
formal reconstructability -/-> consciousness
```

## 5. Harmful recurrence and liberation

```text
rho_h(G,T,E) = Pr(G is re-instantiated in environment E with declared harm h)

pi* = argmin_pi(
  rho_h_after
  + burden_on_weaker_subjects
  + irreversibility
  + epistemic_debt
)
```

subject to source preservation, revision history, successor refusal, explicit authorization and longitudinal reality return.

## 6. DIKWP closure

- **D**: observations, bodily events, testimony and outcomes;
- **I**: differences, relations, contexts, boundaries and carriers;
- **K**: competing causal, identity and world models;
- **W**: values, burdens, legitimacy and affected parties;
- **P**: continuation, repair, liberation or completion contracts.

Every high-impact mapping must be able to return from `P` through action and outcome to revised `D/I/K/W/P`.
