# 来源与主张政策 / Source and Claim Policy

## Claim classes

- **E** established/empirical within a defined domain;
- **H** historical or interpretive reconstruction;
- **F** formal or software construction;
- **P** provisional empirical hypothesis;
- **N** normative or metaphysical proposal;
- **T** tradition-bound doctrinal claim.

A claim may have more than one tag, but tags may not be silently upgraded. `F` does not imply `E`; `T` does not imply universal empirical law; `E` in one domain does not settle `N`.

## Source-bound representation

Every mapped term should preserve source, branch, translation, scope, uncertainty, dissent and revision. Multi-source placeholders are suitable for navigation only; high-impact claims require exact editions, passages, speakers or community review.

## Web and standards drift

Protocol versions and public pages can change after release. Re-verify official specifications before interoperable deployment. The bundle records a snapshot, not a guarantee of future conformance.
