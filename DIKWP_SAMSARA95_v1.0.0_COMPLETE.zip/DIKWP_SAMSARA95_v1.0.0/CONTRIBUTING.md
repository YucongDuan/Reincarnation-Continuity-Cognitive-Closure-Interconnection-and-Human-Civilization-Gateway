# Contributing

Contributions are welcome when they improve evidence, structure, interoperability, accessibility or protection of affected subjects.

A contribution that changes a religious/civilizational mapping should identify the exact tradition or branch, native term, source, translation, disputed interpretation, DIKWP coordinates and non-equivalence boundary. A contribution that changes an identity rule must state the carrier, invariants, threshold, adjudicator, authority scope and foreseeable harm.

Run before submitting:

```bash
python run.py doctor
python -m pytest
python run.py demo --out outputs/samsara_demo
python run.py verify outputs/samsara_demo
```

Do not submit private cognitive passports, alleged past-life identities, medical records, personal confessions or scraped psychological profiles.
