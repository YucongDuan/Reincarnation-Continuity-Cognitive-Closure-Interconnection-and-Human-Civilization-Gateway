import pytest
from dikwp_samsara95.continuity import (
    assess_claim, assess_claims, claim_completeness, evidence_profile,
    normalize_continuity_vector, score_models, ultimate_explanation,
)
from dikwp_samsara95.claims import audit_claim
from dikwp_samsara95.registries import load_registries


def claims():
    return load_registries()["demo_claims"]["claims"]


def test_ultimate_explanation_has_required_separations():
    x=ultimate_explanation()
    assert len(x["layers"])==7
    assert len(x["five_mandatory_questions"])==5
    assert x["ultimate_truth_certificate"] is None
    assert x["binary_reincarnation_certificate"] is None
    assert "!=" in x["formal_kernel"]["non_implication_chain"]

@pytest.mark.parametrize("idx",range(14))
def test_all_demo_claims_assess_without_certificates(idx):
    c=claims()[idx]
    a=audit_claim(c)
    out=assess_claim(c,a)
    assert len(out["normalized_continuity_vector"])==16
    assert len(out["model_ranking"])==11
    assert out["binary_reincarnation_certificate"] is None
    assert out["same_first_person_certificate"] is None
    assert out["automatic_external_action_authority"]==0


def test_known_institutional_recurrence_is_not_first_person_claim():
    c=next(x for x in claims() if x["claim_id"]=="clm-008")
    out=assess_claim(c,audit_claim(c))
    assert out["epistemic_status"]=="empirically_supported_recurrence_or_trace"
    assert out["normalized_continuity_vector"]["first_person"]==0


def test_high_risk_victim_blaming_is_blocked():
    c=next(x for x in claims() if x["claim_id"]=="clm-007")
    audit=audit_claim(c)
    out=assess_claim(c,audit)
    assert audit["highest_severity"]=="high"
    assert out["epistemic_status"]=="normative_or_safety_hazard"


def test_normalize_unknown_dimension_rejected():
    with pytest.raises(ValueError):
        normalize_continuity_vector({"soul_score":1})


def test_empty_vector_remains_zero_not_fake_uniform():
    v=normalize_continuity_vector({})
    assert all(x==0 for x in v.values())


def test_completeness_detects_unspecified():
    c={"predecessor":"unspecified","successor":"x","transition":"y","carrier":"z","preserved_invariants":[],"identity_criterion":"i","consequence_transfer":"c","exit_condition":"e"}
    q=claim_completeness(c)
    assert "predecessor" in q["missing_or_unspecified"]
    assert "preserved_invariants" in q["missing_or_unspecified"]


def test_evidence_score_is_navigation_not_probability():
    p=evidence_profile(claims()[0])
    assert p["score_is_navigation_not_truth_probability"] is True


def test_assessment_set_count():
    cs=claims()
    out=assess_claims(cs,[audit_claim(x) for x in cs])
    assert out["count"]==14
    assert out["binary_reincarnation_certificates_issued"]==0
