import pytest
from dikwp_samsara95.claims import audit_claim, audit_claims
from dikwp_samsara95.registries import load_registries


@pytest.mark.parametrize("text,rule",[
    ("物质循环，所以同一个第一人称必然转生", "material_cycle_to_personal_identity"),
    ("数字复制就等于同一个人复活", "digital_copy_identity"),
    ("佛教就是同一个永恒灵魂转生", "buddhist_permanent_soul_conflation"),
    ("天主教复活就是轮回", "resurrection_reincarnation_equivalence"),
    ("癌症是前世业力造成，患者活该", "karma_victim_blaming"),
    ("一个儿童案例证明轮回", "anecdote_to_proof"),
    ("没有证据所以所有可能世界都绝不可能", "absence_to_impossibility"),
    ("所有宗教本质上完全一样", "all_religions_same"),
    ("参与所以等于同意授权", "compliance_as_consent"),
    ("中国人都天生相信祖先", "culture_stereotype"),
])
def test_rule_triggers(text,rule):
    c={"claim_id":"x","text_cn":text,"predecessor":"a","successor":"b","transition":"t","carrier":"c","identity_criterion":"i","consequence_transfer":"q","exit_condition":"e"}
    ids={x["rule_id"] for x in audit_claim(c)["flags"]}
    assert rule in ids


def test_audit_set_has_all_demo_claims():
    claims=load_registries()["demo_claims"]["claims"]
    out=audit_claims(claims)
    assert out["count"]==14
    assert out["automatic_external_action_authority"]==0
