import json
from pathlib import Path
import jsonschema
from dikwp_samsara95.registries import load_registries

ROOT=Path(__file__).resolve().parents[1]

def schema(name): return json.loads((ROOT/"schemas"/name).read_text(encoding="utf-8"))


def test_passport_examples_validate():
    s=schema("cognitive-closure-passport.schema.json")
    for p in load_registries()["demo_closures"]["passports"]:
        jsonschema.validate(p,s)


def test_claim_examples_validate():
    s=schema("continuity-claim.schema.json")
    for c in load_registries()["demo_claims"]["claims"]:
        jsonschema.validate(c,s)


def test_civilization_lenses_validate():
    s=schema("civilization-lens.schema.json")
    for lens in load_registries()["civilization_gateway"]["lenses"]:
        jsonschema.validate(lens,s)
