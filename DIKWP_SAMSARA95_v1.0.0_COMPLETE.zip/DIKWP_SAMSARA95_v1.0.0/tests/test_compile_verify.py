import json
from pathlib import Path
from dikwp_samsara95.compiler import compile_system
from dikwp_samsara95.verify import verify_output_dir


def test_compile_and_verify(tmp_path):
    out=tmp_path/"compiled"
    b=compile_system(out)
    v=verify_output_dir(out)
    assert v["valid"]
    assert b["summary"]["tradition_concept_count"]==144
    assert b["summary"]["interclosure_bridge_count"]==21
    assert b["summary"]["binary_reincarnation_certificates_issued"]==0
    assert v["checked_manifest_files"]==v["manifest_file_count"]


def test_compilation_deterministic_except_timestamp(tmp_path):
    a=compile_system(tmp_path/"a")
    b=compile_system(tmp_path/"b")
    assert a["compilation_id"]==b["compilation_id"]
    assert a["bundle_digest"]==b["bundle_digest"]


def test_dashboard_is_offline_and_boundary_visible(tmp_path):
    compile_system(tmp_path/"x")
    h=(tmp_path/"x"/"dashboard.html").read_text(encoding="utf-8")
    assert "<script src=" not in h.casefold()
    assert "Automatic external action authority: 0" in h


def test_manifest_detects_tamper(tmp_path):
    out=tmp_path/"x"
    compile_system(out)
    p=out/"FULL_SYSTEM_REPORT_CN.md"
    p.write_text(p.read_text(encoding="utf-8")+"tamper",encoding="utf-8")
    v=verify_output_dir(out)
    assert not v["valid"]
    assert any("Digest mismatch" in x for x in v["errors"])
