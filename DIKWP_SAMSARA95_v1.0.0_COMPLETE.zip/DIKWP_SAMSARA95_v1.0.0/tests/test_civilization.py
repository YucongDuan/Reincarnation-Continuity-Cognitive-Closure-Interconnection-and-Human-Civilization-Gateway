from dikwp_samsara95.civilization import build_human_civilization_gateway, query_gateway, to_jsonld


def test_gateway_plural_and_safe():
    g=build_human_civilization_gateway()
    assert g["lens_count"]==22
    assert g["plural_and_non_total"] is True
    c=g["machine_reading_contract"]
    assert c["individual_self_description_has_priority_over_group_inference"] is True
    assert c["no_hidden_psychographic_targeting"] is True
    assert c["automatic_human_representation_authority"]==0


def test_query_consent_surfaces_relevant_lens():
    q=query_gateway("同意、权力与AI",6)
    ids={x["id"] for x in q["selected_lenses"]}
    assert "privacy_consent" in ids
    assert "power_status_asymmetry" in ids


def test_jsonld_minimum_structure():
    j=to_jsonld()
    assert j["@context"]["@version"]==1.1
    assert j["@id"].startswith("urn:dikwp:samsara95")
    assert len(j["lenses"])==22
