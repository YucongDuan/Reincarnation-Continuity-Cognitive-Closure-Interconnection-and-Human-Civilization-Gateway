from dikwp_samsara95.registries import load_registries, validate_registries


def test_registry_validation():
    assert validate_registries()["valid"]


def test_registry_counts():
    c=validate_registries()["counts"]
    assert c["dikwp_anchors"]==32
    assert c["continuity_dimensions"]==16
    assert c["continuity_models"]==11
    assert c["traditions"]==36
    assert c["tradition_concepts"]==144
    assert c["tradition_mappings"]==36
    assert c["sources"]==31
    assert c["civilization_lenses"]==22


def test_model_weights_and_certificates():
    r=load_registries()["continuity_models"]
    for m in r["models"]:
        assert abs(sum(m["continuity_weights"].values())-1)<1e-6
        assert m["binary_reincarnation_certificate"] is None


def test_tradition_mapping_non_equivalence_and_space_closure():
    r=load_registries()["tradition_mappings"]
    assert r["permanent_outside_semantic_zone"] is False
    assert r["out_of_space_residual"]==0
    assert all(x["doctrinal_equivalence_claim"] is False for x in r["records"])


def test_governance_all_authorities_zero():
    g=load_registries()["governance"]
    assert g["authorities"]
    assert all(v==0 for v in g["authorities"].values())


def test_demo_data_is_synthetic():
    r=load_registries()
    assert r["demo_closures"]["synthetic_only"] is True
    assert r["demo_claims"]["synthetic_only"] is True
