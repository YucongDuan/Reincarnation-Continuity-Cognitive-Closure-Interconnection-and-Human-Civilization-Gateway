from pathlib import Path
import json, os, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
ENV=dict(os.environ,PYTHONPATH=str(ROOT/"src"))


def run(*args):
    return subprocess.run([sys.executable,str(ROOT/"run.py"),*args],cwd=ROOT,env=ENV,text=True,capture_output=True)


def test_doctor_cli():
    p=run("doctor")
    assert p.returncode==0
    assert json.loads(p.stdout)["valid"] is True


def test_explain_cli():
    p=run("explain")
    assert p.returncode==0
    assert json.loads(p.stdout)["ultimate_truth_certificate"] is None


def test_assess_free_text_is_underdetermined():
    p=run("assess","--text","也许某种模式会返回")
    assert p.returncode==0
    assert json.loads(p.stdout)["assessment"]["epistemic_status"]=="underdetermined_claim"


def test_civilization_query_cli():
    p=run("civilization","--query","同意 权力")
    assert p.returncode==0
    assert json.loads(p.stdout)["automatic_identity_assignment_authority"]==0


def test_tradition_unknown_returns_structured_error():
    p=run("tradition","not-a-tradition")
    assert p.returncode==2
    assert "error" in json.loads(p.stdout)


def test_profiles_cli():
    p=run("profiles")
    assert p.returncode==0
    x=json.loads(p.stdout)
    assert x["mcp"]["protocolVersion"]=="2026-07-28"
    assert x["a2a"]["supportedInterfaces"][0]["protocolVersion"]=="1.0"
