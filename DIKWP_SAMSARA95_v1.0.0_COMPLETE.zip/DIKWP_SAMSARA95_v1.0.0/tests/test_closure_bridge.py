import pytest
from dikwp_samsara95.bridge import build_bridge, build_bridge_matrix, build_handshake
from dikwp_samsara95.closure import compile_passport, public_passport_view, validate_passport
from dikwp_samsara95.registries import load_registries


def passports():
    return load_registries()["demo_closures"]["passports"]


@pytest.mark.parametrize("idx",range(7))
def test_passports_compile_deterministically(idx):
    p=passports()[idx]
    a=compile_passport(p); b=compile_passport(a)
    assert a["passport_digest"]==b["passport_digest"]
    assert a["compiled_id"]==b["compiled_id"]
    assert a["identity_certificate"] is None


def test_invalid_consent_rejected():
    p=dict(passports()[0])
    p["consent"]=dict(p["consent"],inferred_from_participation=True)
    assert not validate_passport(p)["valid"]


def test_public_view_excludes_sensitive_fields():
    v=public_passport_view(passports()[0])
    assert "vulnerabilities" not in v
    assert "memory" not in v
    assert v["disclosure_contract"]["not_disclosed_is_not_absent"] is True


def test_bridge_has_no_identity_or_connection_authority():
    b=build_bridge(passports()[0],passports()[4])
    assert b["identity_equivalence_certificate"] is None
    assert b["consciousness_equivalence_certificate"] is None
    assert b["automatic_connection_authority"]==0
    assert b["automatic_external_action_authority"]==0


def test_all_pairs_matrix_count():
    ps=passports()
    m=build_bridge_matrix(ps)
    assert m["bridge_count"]==len(ps)*(len(ps)-1)//2==21


def test_handshake_is_proposal_only_and_revocable():
    h=build_handshake(passports()[0],passports()[4])
    assert len(h["stages"])==7
    assert h["connection_authorized"] is False
    assert h["external_action_authorized"] is False
    assert h["implicit_consent_allowed"] is False
    assert h["one_party_may_disconnect"] is True
