import json
from dikwp_samsara95.interop import build_a2a_agent_card, build_mcp_manifest, build_openapi, mcp_tools
from dikwp_samsara95.mcp_stdio import dispatch

META={"_meta":{"io.modelcontextprotocol/protocolVersion":"2026-07-28"}}


def test_mcp_manifest_read_only():
    m=build_mcp_manifest()
    assert m["protocolVersion"]=="2026-07-28"
    assert m["stateless"] is True
    assert len(m["tools"])==6
    assert all(x["annotations"]["readOnlyHint"] for x in m["tools"])
    assert m["security"]["automaticExternalActionAuthority"]==0


def test_server_discovery_without_version():
    r=dispatch({"jsonrpc":"2.0","id":1,"method":"server/discover","params":{}})
    assert r["result"]["supportedProtocolVersions"]==["2026-07-28"]


def test_wrong_mcp_version_rejected():
    r=dispatch({"jsonrpc":"2.0","id":2,"method":"tools/list","params":{"_meta":{"io.modelcontextprotocol/protocolVersion":"old"}}})
    assert r["error"]["code"]==-32022


def test_tools_list_and_call():
    r=dispatch({"jsonrpc":"2.0","id":3,"method":"tools/list","params":META})
    assert len(r["result"]["tools"])==6
    c=dispatch({"jsonrpc":"2.0","id":4,"method":"tools/call","params":dict(META,name="explain_reincarnation",arguments={})})
    assert c["result"]["isError"] is False
    assert c["result"]["structuredContent"]["ultimate_truth_certificate"] is None


def test_mcp_notifications_have_no_response():
    assert dispatch({"jsonrpc":"2.0","method":"tools/list","params":META}) is None


def test_a2a_profile_fields_and_limits():
    c=build_a2a_agent_card()
    for key in ["name","description","supportedInterfaces","version","capabilities","defaultInputModes","defaultOutputModes","skills"]:
        assert key in c
    assert c["supportedInterfaces"][0]["protocolVersion"]=="1.0"


def test_openapi_is_local_read_only_analytical_surface():
    o=build_openapi()
    assert o["openapi"]=="3.1.0"
    assert o["servers"][0]["url"].startswith("http://127.0.0.1")
    assert "/v1/claims/assess" in o["paths"]
