# AI / Agent 互操作通道 / AI-Agent Interoperability Gateway

DIKWP-SAMSARA95 simultaneously exposes four representations:

1. **Native JSON** for deterministic local processing.
2. **JSON-LD 1.1** for graph-compatible linked-data interchange.
3. **A2A v1.0 Agent Card profile** for discoverable capability description.
4. **MCP 2026-07-28 read-only stdio reference adapter** for tools and resources.

## A2A boundary

The package includes an Agent Card using the v1.0 field structure (`supportedInterfaces`, capabilities, media types and skills). It is a **profile artifact**, not an independently certified or deployed A2A server. The placeholder endpoint must be replaced and secured before deployment.

## MCP boundary

The stdio adapter supports:

```text
server/discover
tools/list
tools/call
resources/list
resources/read
```

Every modern request other than the discovery probe must carry protocol version `2026-07-28` in `_meta`. The adapter is stateless and newline-delimited JSON-RPC 2.0. All tools are read-only and return structured content; none may publish, send messages, operate facilities, assign identity or modify a person.

## Available tools

- `explain_reincarnation`
- `assess_continuity_claim`
- `get_human_civilization_gateway`
- `bridge_cognitive_closures`
- `build_interclosure_handshake`
- `map_tradition_continuity`

## Critical interpretation rule

Interoperability only means systems can exchange declared structures. It does **not** establish shared consciousness, identical meaning, legal identity, moral authority or informed consent.

```text
automatic_external_action_authority = 0
identity_equivalence_certificate = null
consciousness_equivalence_certificate = null
```
