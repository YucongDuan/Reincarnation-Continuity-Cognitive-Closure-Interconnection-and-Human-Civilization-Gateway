from dikwp_samsara95.cli import main

if __name__ == "__main__":
    main()
